<?php
/** بارگذاری تنظیمات؛ اگر ../sonia-config.php (بیرون از public_html) باشد همان اولویت دارد */
class Config
{
    private static ?array $c = null;

    private static function file(): ?string
    {
        $root = dirname(__DIR__);
        foreach ([dirname($root) . '/sonia-config.php', $root . '/config.php'] as $f) {
            if (is_file($f)) return $f;
        }
        return null;
    }

    public static function exists(): bool { return self::file() !== null; }

    public static function load(): array
    {
        if (self::$c !== null) return self::$c;
        $f = self::file();
        if (!$f) throw new RuntimeException('config missing');
        return self::$c = (array) require $f;
    }
}
