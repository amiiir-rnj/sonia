<?php

class Auth
{
    private static ?string $dummy = null;

    public static function hashToken(string $token): string
    {
        return hash('sha256', $token);
    }

    public static function userCount(): int
    {
        return (int) Database::pdo()->query('SELECT COUNT(*) FROM users')->fetchColumn();
    }

    public static function ip(): string
    {
        return substr((string) ($_SERVER['REMOTE_ADDR'] ?? '0'), 0, 64);
    }

    public static function isHttps(): bool
    {
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    }

    public static function setup(array $in): array
    {
        Rules::require(self::userCount() === 0, 'راه‌اندازی اولیه قبلاً انجام شده است');
        $cfg = Config::load();
        $key = (string) ($cfg['setup_key'] ?? '');
        Rules::require($key !== '', 'ابتدا setup_key را در config.php تنظیم کنید', 403);
        Rules::require(hash_equals($key, (string) ($in['setupKey'] ?? '')), 'کلید راه‌اندازی نامعتبر است', 403);
        $name = Rules::text($in['name'] ?? null);
        $username = strtolower(Rules::text($in['username'] ?? null, 80));
        $password = (string) ($in['password'] ?? '');
        Rules::require(mb_strlen($password) >= 12 && mb_strlen($password) <= 200, 'رمز باید بین ۱۲ تا ۲۰۰ نویسه باشد');

        $id = Rules::uuid();
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $db = Database::pdo();
        $db->prepare('INSERT INTO users (id, username, name, role, password, active, failures) VALUES (?,?,?,?,?,?,0)')
            ->execute([$id, $username, $name, 'Admin', $hash, 1]);

        if ((int) $db->query('SELECT COUNT(*) FROM price_levels')->fetchColumn() === 0) {
            foreach (['سطح ۱', 'سطح ۲', 'سطح ۳'] as $n) {
                $db->prepare('INSERT INTO price_levels (id, name) VALUES (?,?)')->execute([Rules::uuid(), $n]);
            }
        }
        if ((int) $db->query('SELECT COUNT(*) FROM warehouses')->fetchColumn() === 0) {
            $db->prepare('INSERT INTO warehouses (id, name) VALUES (?,?)')->execute([Rules::uuid(), 'انبار مرکزی']);
        }
        return ['ok' => true, 'id' => $id];
    }

    public static function login(array $in): array
    {
        $username = strtolower(trim((string) ($in['username'] ?? '')));
        $username = substr($username, 0, 80);
        $password = (string) ($in['password'] ?? '');
        $db = Database::pdo();
        $ip = self::ip();
        $win = date('Y-m-d H:i:s', time() - 900);

        $db->prepare('DELETE FROM login_attempts WHERE at < ?')->execute([$win]);
        $st = $db->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip=? AND username=?');
        $st->execute([$ip, $username]);
        $perUser = (int) $st->fetchColumn();
        $st = $db->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip=?');
        $st->execute([$ip]);
        $perIp = (int) $st->fetchColumn();
        if ($perUser >= 5 || $perIp >= 30) {
            throw new RuleException('تلاش‌های ناموفق زیاد است؛ چند دقیقه بعد دوباره امتحان کنید', 429);
        }

        $st = $db->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
        $st->execute([$username]);
        $user = $st->fetch();
        // زمان پاسخ برای کاربر ناموجود هم یکسان باشد
        self::$dummy ??= password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT);
        $okPass = password_verify($password, $user ? $user['password'] : self::$dummy);
        if (!$user || !(int) $user['active'] || !$okPass) {
            $db->prepare('INSERT INTO login_attempts (ip, username, at) VALUES (?,?,?)')->execute([$ip, $username, date('Y-m-d H:i:s')]);
            throw new RuleException('نام کاربری یا رمز اشتباه است', 401);
        }
        $db->prepare('DELETE FROM login_attempts WHERE ip=? AND username=?')->execute([$ip, $username]);
        $db->prepare('DELETE FROM sessions WHERE expires < ?')->execute([date('Y-m-d H:i:s')]);

        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', time() + 7 * 86400);
        $db->prepare('INSERT INTO sessions (hash, user_id, expires) VALUES (?,?,?)')
            ->execute([self::hashToken($token), $user['id'], $expires]);

        setcookie('sonia', $token, [
            'expires' => time() + 7 * 86400,
            'path' => '/',
            'secure' => self::isHttps(),
            'httponly' => true,
            'samesite' => 'Strict',
        ]);

        // توکن عمداً در پاسخ برنگردانده می‌شود (فقط کوکی HttpOnly)
        return [
            'name' => $user['name'],
            'role' => $user['role'],
            'expires' => date('c', strtotime($expires)),
        ];
    }

    public static function logout(?string $tokenHash): array
    {
        if ($tokenHash) {
            Database::pdo()->prepare('DELETE FROM sessions WHERE hash=?')->execute([$tokenHash]);
        }
        setcookie('sonia', '', ['expires' => time() - 3600, 'path' => '/', 'secure' => self::isHttps(), 'httponly' => true, 'samesite' => 'Strict']);
        return ['ok' => true];
    }

    /** @return array{user:array,tokenHash:string} */
    public static function requireUser(): array
    {
        $auth = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
        $token = '';
        if (stripos($auth, 'Bearer ') === 0) {
            $token = substr($auth, 7);
        } elseif (!empty($_COOKIE['sonia'])) {
            $token = $_COOKIE['sonia'];
        }
        Rules::require($token !== '', 'ابتدا وارد شوید', 401);
        $hash = self::hashToken($token);
        $db = Database::pdo();
        $st = $db->prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.hash=? AND s.expires > ? AND u.active=1 LIMIT 1');
        $st->execute([$hash, date('Y-m-d H:i:s')]);
        $user = $st->fetch();
        Rules::require((bool) $user, 'نشست منقضی شده است', 401);
        return ['user' => $user, 'tokenHash' => $hash];
    }

    public static function requireAdmin(array $user): void
    {
        Rules::require(($user['role'] ?? '') === 'Admin', 'فقط مدیر', 403);
    }
}
