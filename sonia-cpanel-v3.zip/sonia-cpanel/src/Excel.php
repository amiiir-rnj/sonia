<?php
/** خروجی اکسل ساده (SpreadsheetML) بدون کتابخانه خارجی */
class Excel
{
    public static function send(string $filename, array $headers, array $rows): void
    {
        $filename = preg_replace('/[^\w\-\.]+/u', '_', $filename);
        if (!str_ends_with(strtolower($filename), '.xls')) {
            $filename .= '.xls';
        }
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: max-age=0');

        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<?mso-application progid="Excel.Sheet"?>' . "\n";
        echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"'
            . ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
            . '<Styles><Style ss:ID="h"><Font ss:Bold="1"/></Style></Styles>'
            . '<Worksheet ss:Name="Report"><Table>';

        echo '<Row>';
        foreach ($headers as $h) {
            echo '<Cell ss:StyleID="h"><Data ss:Type="String">' . self::esc($h) . '</Data></Cell>';
        }
        echo '</Row>';

        foreach ($rows as $row) {
            echo '<Row>';
            foreach ($row as $cell) {
                if (is_int($cell) || is_float($cell)) {
                    echo '<Cell><Data ss:Type="Number">' . self::esc((string) $cell) . '</Data></Cell>';
                } else {
                    echo '<Cell><Data ss:Type="String">' . self::esc((string) $cell) . '</Data></Cell>';
                }
            }
            echo '</Row>';
        }
        echo '</Table></Worksheet></Workbook>';
        exit;
    }

    private static function esc(string $s): string
    {
        return htmlspecialchars($s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }
}
