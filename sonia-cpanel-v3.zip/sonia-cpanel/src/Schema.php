<?php

class Schema
{
    public static function install(): void
    {
        $db = Database::pdo();
        $driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
        $id = $driver === 'sqlite' ? 'TEXT' : 'CHAR(36)';
        $bool = $driver === 'sqlite' ? 'INTEGER' : 'TINYINT(1)';
        $text = $driver === 'sqlite' ? 'TEXT' : 'VARCHAR';
        $dec = $driver === 'sqlite' ? 'TEXT' : 'DECIMAL';
        $ts = $driver === 'sqlite' ? 'TEXT' : 'DATETIME';
        $ai = $driver === 'sqlite' ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY';

        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS users (
            id $id PRIMARY KEY,
            username {$text}(80) NOT NULL UNIQUE,
            name {$text}(160) NOT NULL,
            role {$text}(20) NOT NULL DEFAULT 'Visitor',
            password {$text}(255) NOT NULL,
            active $bool NOT NULL DEFAULT 1,
            failures $bool NOT NULL DEFAULT 0,
            locked_until $ts NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS sessions (
            hash {$text}(64) PRIMARY KEY,
            user_id $id NOT NULL,
            expires $ts NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS price_levels (
            id $id PRIMARY KEY,
            name {$text}(80) NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS warehouses (
            id $id PRIMARY KEY,
            name {$text}(120) NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS products (
            id $id PRIMARY KEY,
            sku {$text}(80) NOT NULL UNIQUE,
            name {$text}(160) NOT NULL,
            unit {$text}(10) NOT NULL DEFAULT 'kg',
            minimum_stock $dec(14,3) NOT NULL DEFAULT 0
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS product_prices (
            product_id $id NOT NULL,
            price_level_id $id NOT NULL,
            amount $dec(18,0) NOT NULL DEFAULT 0,
            PRIMARY KEY (product_id, price_level_id)
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS customers (
            id $id PRIMARY KEY,
            name {$text}(160) NOT NULL,
            phone {$text}(40) NULL,
            address {$text}(500) NULL,
            price_level_id $id NOT NULL,
            visitor_id $id NULL,
            opening_debt $dec(18,0) NOT NULL DEFAULT 0
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS stocks (
            product_id $id NOT NULL,
            warehouse_id $id NOT NULL,
            quantity $dec(14,3) NOT NULL DEFAULT 0,
            PRIMARY KEY (product_id, warehouse_id)
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS movements (
            id $id PRIMARY KEY,
            product_id $id NOT NULL,
            warehouse_id $id NOT NULL,
            delta $dec(14,3) NOT NULL,
            source_id $id NULL,
            reason {$text}(200) NOT NULL DEFAULT '',
            at $ts NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS orders (
            id $id PRIMARY KEY,
            customer_id $id NOT NULL,
            warehouse_id $id NOT NULL,
            creator_id $id NOT NULL,
            channel {$text}(40) NOT NULL DEFAULT 'حضوری',
            status {$text}(30) NOT NULL DEFAULT 'Submitted',
            discount $dec(18,0) NOT NULL DEFAULT 0,
            at $ts NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS order_lines (
            id $id PRIMARY KEY,
            order_id $id NOT NULL,
            product_id $id NOT NULL,
            name {$text}(160) NOT NULL,
            unit {$text}(10) NOT NULL,
            quantity $dec(14,3) NOT NULL,
            price $dec(18,0) NOT NULL,
            total $dec(18,0) NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS invoices (
            id $id PRIMARY KEY,
            order_id $id NOT NULL UNIQUE,
            number BIGINT NOT NULL UNIQUE,
            total $dec(18,0) NOT NULL,
            status {$text}(20) NOT NULL DEFAULT 'Posted',
            at $ts NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS payments (
            id $id PRIMARY KEY,
            invoice_id $id NULL,
            customer_id $id NOT NULL,
            method {$text}(30) NOT NULL,
            amount $dec(18,0) NOT NULL,
            reference {$text}(120) NULL,
            at $ts NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS checks (
            id $id PRIMARY KEY,
            payment_id $id NOT NULL UNIQUE,
            bank {$text}(80) NOT NULL,
            number {$text}(40) NOT NULL,
            due DATE NOT NULL,
            amount $dec(18,0) NOT NULL,
            status {$text}(20) NOT NULL DEFAULT 'Pending'
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS opening_receipts (
            id $id PRIMARY KEY,
            customer_id $id NOT NULL,
            amount $dec(18,0) NOT NULL,
            method {$text}(30) NOT NULL,
            reference {$text}(120) NULL,
            at $ts NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS visits (
            id $id PRIMARY KEY,
            customer_id $id NOT NULL,
            visitor_id $id NOT NULL,
            day DATE NOT NULL,
            status {$text}(20) NOT NULL DEFAULT 'Planned'
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS audits (
            id $ai,
            actor_id $id NULL,
            action {$text}(80) NOT NULL,
            target_id $id NULL,
            detail {$text}(500) NULL,
            at $ts NOT NULL
        )";

        $sql[] = "CREATE TABLE IF NOT EXISTS command_receipts (
            `key` $id PRIMARY KEY,
            actor_id $id NOT NULL,
            action {$text}(80) NOT NULL,
            fingerprint {$text}(64) NOT NULL,
            result TEXT NULL,
            at $ts NOT NULL
        )";

        foreach ($sql as $q) {
            $db->exec($q);
        }
    }

    public const VERSION = 3;

    /** فقط وقتی نسخه‌ی اسکیما قدیمی است مهاجرت اجرا می‌شود (نه در هر درخواست) */
    public static function ensure(): void
    {
        $db = Database::pdo();
        $v = 0;
        try {
            $v = (int) $db->query("SELECT `value` FROM settings WHERE `key`='schema_version'")->fetchColumn();
        } catch (Throwable $e) {
            try { $db->query('SELECT 1 FROM users LIMIT 1'); } catch (Throwable $e2) { self::install(); }
        }
        if ($v < self::VERSION) {
            self::upgrade();
        }
    }

    /** جداول نسخه ارتقا */
    public static function upgrade(): void
    {
        $db = Database::pdo();
        $driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
        $id = $driver === 'sqlite' ? 'TEXT' : 'CHAR(36)';
        $text = $driver === 'sqlite' ? 'TEXT' : 'VARCHAR';
        $ts = $driver === 'sqlite' ? 'TEXT' : 'DATETIME';
        $dec = $driver === 'sqlite' ? 'TEXT' : 'DECIMAL';

        $db->exec("CREATE TABLE IF NOT EXISTS settings (
            `key` {$text}(80) PRIMARY KEY,
            `value` TEXT NULL
        )");

        $db->exec("CREATE TABLE IF NOT EXISTS visitor_presence (
            id $id PRIMARY KEY,
            visitor_id $id NOT NULL,
            lat $dec(10,7) NULL,
            lng $dec(10,7) NULL,
            accuracy $dec(10,2) NULL,
            note {$text}(200) NULL,
            at $ts NOT NULL
        )");

        $db->exec("CREATE TABLE IF NOT EXISTS proformas (
            id $id PRIMARY KEY,
            number BIGINT NOT NULL,
            customer_id $id NOT NULL,
            warehouse_id $id NOT NULL,
            creator_id $id NOT NULL,
            discount $dec(18,0) NOT NULL DEFAULT 0,
            total $dec(18,0) NOT NULL DEFAULT 0,
            status {$text}(20) NOT NULL DEFAULT 'Draft',
            note {$text}(500) NULL,
            at $ts NOT NULL
        )");

        $db->exec("CREATE TABLE IF NOT EXISTS proforma_lines (
            id $id PRIMARY KEY,
            proforma_id $id NOT NULL,
            product_id $id NOT NULL,
            name {$text}(160) NOT NULL,
            unit {$text}(10) NOT NULL,
            quantity $dec(14,3) NOT NULL,
            price $dec(18,0) NOT NULL,
            total $dec(18,0) NOT NULL
        )");

        $db->exec("CREATE TABLE IF NOT EXISTS stock_batches (
            id $id PRIMARY KEY,
            product_id $id NOT NULL,
            warehouse_id $id NOT NULL,
            quantity $dec(14,3) NOT NULL DEFAULT 0,
            expires_on DATE NULL,
            movement_id $id NULL,
            at $ts NOT NULL
        )");
        try { $db->exec("CREATE INDEX idx_batches_expiry ON stock_batches (expires_on)"); } catch (Throwable $e) {}
        try { $db->exec("CREATE INDEX idx_batches_product ON stock_batches (product_id, warehouse_id)"); } catch (Throwable $e) {}

        $db->exec("CREATE TABLE IF NOT EXISTS customer_prices (
            customer_id $id NOT NULL,
            product_id $id NOT NULL,
            amount $dec(18,0) NOT NULL DEFAULT 0,
            PRIMARY KEY (customer_id, product_id)
        )");
        $db->exec("CREATE TABLE IF NOT EXISTS report_notes (
            id $id PRIMARY KEY,
            author_id $id NOT NULL,
            title {$text}(200) NOT NULL,
            body TEXT NOT NULL,
            related_type {$text}(40) NULL,
            related_id $id NULL,
            at $ts NOT NULL
        )");
        foreach ([
            "ALTER TABLE visits ADD COLUMN skip_reason VARCHAR(300) NULL",
            "ALTER TABLE visits ADD COLUMN checkin_lat DECIMAL(10,7) NULL",
            "ALTER TABLE visits ADD COLUMN checkin_lng DECIMAL(10,7) NULL",
            "ALTER TABLE visits ADD COLUMN completed_at DATETIME NULL",
        ] as $sql) {
            try { $db->exec($sql); } catch (Throwable $e) {}
        }

        $ai = $driver === 'sqlite' ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY';
        $db->exec("CREATE TABLE IF NOT EXISTS counters (name {$text}(40) PRIMARY KEY, value BIGINT NOT NULL DEFAULT 0)");
        $db->exec("CREATE TABLE IF NOT EXISTS login_attempts (id $ai, ip {$text}(64) NOT NULL, username {$text}(80) NOT NULL, at $ts NOT NULL)");
        foreach (['invoices', 'proformas'] as $cn) {
            $has = $db->prepare('SELECT COUNT(*) FROM counters WHERE name=?');
            $has->execute([$cn]);
            if ((int) $has->fetchColumn() === 0) {
                $mx = (int) $db->query("SELECT COALESCE(MAX(number),0) FROM {$cn}")->fetchColumn();
                $db->prepare('INSERT INTO counters (name, value) VALUES (?,?)')->execute([$cn, $mx]);
            }
        }
        foreach ([
            'CREATE INDEX idx_orders_customer ON orders (customer_id)',
            'CREATE INDEX idx_orders_creator ON orders (creator_id, at)',
            'CREATE INDEX idx_lines_order ON order_lines (order_id)',
            'CREATE INDEX idx_pay_customer ON payments (customer_id)',
            'CREATE INDEX idx_pay_invoice ON payments (invoice_id)',
            'CREATE INDEX idx_visits_visitor ON visits (visitor_id, day)',
            'CREATE INDEX idx_visits_customer ON visits (customer_id)',
            'CREATE INDEX idx_moves_at ON movements (at)',
            'CREATE INDEX idx_moves_product ON movements (product_id)',
            'CREATE INDEX idx_checks_status ON checks (status, due)',
            'CREATE INDEX idx_sessions_user ON sessions (user_id)',
            'CREATE INDEX idx_sessions_exp ON sessions (expires)',
            'CREATE INDEX idx_presence_visitor ON visitor_presence (visitor_id, at)',
            'CREATE INDEX idx_attempts_ip ON login_attempts (ip, at)',
        ] as $ix) {
            try { $db->exec($ix); } catch (Throwable $e) {}
        }

        foreach ([
            "ALTER TABLE products ADD COLUMN perishable TINYINT NOT NULL DEFAULT 0",
            "ALTER TABLE products ADD COLUMN shelf_life_days INT NULL",
            "ALTER TABLE products ADD COLUMN expiry_alert_days INT NOT NULL DEFAULT 30",
            "ALTER TABLE stock_batches ADD COLUMN lot_no VARCHAR(60) NULL",
            "ALTER TABLE stock_batches ADD COLUMN prev_batch_id CHAR(36) NULL",
            "ALTER TABLE stock_batches ADD COLUMN diff_days INT NULL",
            "ALTER TABLE stock_batches ADD COLUMN initial_qty DECIMAL(14,3) NULL",
            "ALTER TABLE stock_batches ADD COLUMN depleted_at DATETIME NULL",
        ] as $sql) {
            try { $db->exec($sql); } catch (Throwable $e) {}
        }
        $db->exec("CREATE TABLE IF NOT EXISTS batch_allocations (
            order_id $id NOT NULL,
            batch_id $id NOT NULL,
            quantity $dec(14,3) NOT NULL,
            PRIMARY KEY (order_id, batch_id)
        )");
        try { $db->exec('CREATE INDEX idx_alloc_batch ON batch_allocations (batch_id)'); } catch (Throwable $e) {}
        try { $db->exec('CREATE INDEX idx_batches_active ON stock_batches (product_id, warehouse_id, depleted_at)'); } catch (Throwable $e) {}

        // پرکردن سابقه‌ی دسته‌های قدیمی: مقدار اولیه، دسته‌ی قبلی و اختلاف انقضا
        $old = $db->query('SELECT id, product_id, warehouse_id, expires_on, quantity FROM stock_batches WHERE initial_qty IS NULL ORDER BY product_id, warehouse_id, at, id')->fetchAll();
        $last = [];
        foreach ($old as $b) {
            $k = $b['product_id'] . '|' . $b['warehouse_id'];
            $prev = $last[$k] ?? null;
            $diff = ($prev && $prev['expires_on'] && $b['expires_on'])
                ? (int) round((strtotime($b['expires_on']) - strtotime($prev['expires_on'])) / 86400) : null;
            $db->prepare('UPDATE stock_batches SET initial_qty=?, prev_batch_id=?, diff_days=? WHERE id=?')
                ->execute([$b['quantity'], $prev['id'] ?? null, $diff, $b['id']]);
            $last[$k] = $b;
        }

        // defaults
        $defaults = [
            'company_name' => 'شرکت پخش سونیا',
            'office_name' => 'دفتر مرکزی',
            'invoice_title' => 'فاکتور فروش',
            'proforma_title' => 'پیش‌فاکتور',
            'invoice_footer' => 'مبالغ به تومان است. فاکتور داخلی.',
            'invoice_prefix' => '',
            'proforma_prefix' => 'P-',
            'show_company_on_print' => '1',
            'print_template' => 'detailed',
            'print_show_logo_text' => '1',
            'print_paper' => 'A4',
        ];
        foreach ($defaults as $k => $v) {
            if ($driver === 'sqlite') {
                $db->prepare('INSERT OR IGNORE INTO settings (`key`,`value`) VALUES (?,?)')->execute([$k, $v]);
            } else {
                $db->prepare('INSERT IGNORE INTO settings (`key`,`value`) VALUES (?,?)')->execute([$k, $v]);
            }
        }
        if ($driver === 'sqlite') {
            $db->exec("INSERT OR REPLACE INTO settings (`key`,`value`) VALUES ('schema_version','" . self::VERSION . "')");
        } else {
            $db->exec("INSERT INTO settings (`key`,`value`) VALUES ('schema_version','" . self::VERSION . "') ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)");
        }
    }
}
