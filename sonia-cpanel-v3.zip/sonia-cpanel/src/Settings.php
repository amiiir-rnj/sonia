<?php

class Settings
{
    public static function all(): array
    {
        $rows = Database::pdo()->query('SELECT `key`,`value` FROM settings')->fetchAll();
        $out = [];
        foreach ($rows as $r) {
            $out[$r['key']] = $r['value'];
        }
        return $out;
    }

    public static function get(string $key, string $default = ''): string
    {
        $st = Database::pdo()->prepare('SELECT `value` FROM settings WHERE `key`=?');
        $st->execute([$key]);
        $v = $st->fetchColumn();
        return $v === false ? $default : (string) $v;
    }

    public static function setMany(array $pairs): void
    {
        $db = Database::pdo();
        $driver = $db->getAttribute(PDO::ATTR_DRIVER_NAME);
        foreach ($pairs as $k => $v) {
            $k = substr(preg_replace('/[^a-z0-9_]/i', '', (string) $k), 0, 80);
            if ($k === '') continue;
            $v = is_string($v) ? mb_substr($v, 0, 2000) : (string) $v;
            if ($driver === 'sqlite') {
                $db->prepare('INSERT OR REPLACE INTO settings (`key`,`value`) VALUES (?,?)')->execute([$k, $v]);
            } else {
                $db->prepare('INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)')
                    ->execute([$k, $v]);
            }
        }
    }
}
