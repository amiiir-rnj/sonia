<?php

class RuleException extends Exception
{
    public int $status;
    public function __construct(string $message, int $status = 400)
    {
        parent::__construct($message);
        $this->status = $status;
    }
}

class Rules
{
    public static function money($value): string
    {
        return (string) (int) round((float) $value, 0, PHP_ROUND_HALF_UP);
    }

    public static function require(bool $ok, string $msg, int $status = 400): void
    {
        if (!$ok) {
            throw new RuleException($msg, $status);
        }
    }

    public static function text(?string $value, int $max = 160): string
    {
        self::require($value !== null, 'متن لازم است');
        $value = trim($value);
        self::require($value !== '' && mb_strlen($value) <= $max, 'متن خالی یا بیش از حد طولانی است');
        return $value;
    }

    public static function quantity(string $unit, $q): void
    {
        self::require(in_array($unit, ['kg', 'count'], true), 'واحد نامعتبر');
        $q = (float) $q;
        self::require($q > 0 && $q <= 1000000, 'مقدار باید مثبت و حداکثر یک میلیون باشد');
        self::require(round($q, 3) == $q, 'دقت وزن حداکثر سه رقم اعشار است');
        if ($unit === 'count') {
            self::require(floor($q) == $q, 'تعداد باید صحیح باشد');
        }
    }

    public static function lineTotal(string $unit, $quantity, $price): string
    {
        self::quantity($unit, $quantity);
        $price = (float) $price;
        self::require($price >= 0 && $price <= 1_000_000_000, 'قیمت نامعتبر است');
        return self::money((float) $quantity * $price);
    }

    public static function payment(array $p): void
    {
        self::require(in_array($p['method'] ?? '', ['Cash', 'Card', 'BankTransfer', 'Check'], true), 'روش دریافت نامعتبر');
        $amount = (float) ($p['amount'] ?? 0);
        self::require($amount > 0 && $amount <= 1_000_000_000_000, 'مبلغ دریافت نامعتبر');
        if (($p['method'] ?? '') === 'Check') {
            self::require(!empty($p['due']) && !empty($p['bank']) && !empty($p['number']), 'بانک، شماره و سررسید چک لازم است');
        }
    }

    public static function coord($v, int $limit): ?float
    {
        if ($v === null || $v === '' || !is_numeric($v)) return null;
        $f = (float) $v;
        return abs($f) <= $limit ? $f : null;
    }

    public static function uuid(): string
    {
        $b = random_bytes(16);
        $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
        $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($b), 4));
    }
}
