<?php

class Finance
{
    public static function audit(?array $actor, string $action, ?string $targetId = null, ?string $detail = null): void
    {
        Database::pdo()->prepare('INSERT INTO audits (actor_id, action, target_id, detail, at) VALUES (?,?,?,?,?)')
            ->execute([$actor['id'] ?? null, $action, $targetId, $detail, date('Y-m-d H:i:s')]);
    }

    public static function idempotent(array $actor, string $key, string $action, array $input, callable $work): array
    {
        $fp = hash('sha256', json_encode($input, JSON_UNESCAPED_UNICODE));
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM command_receipts WHERE `key`=?');
        $st->execute([$key]);
        $ex = $st->fetch();
        if ($ex) {
            Rules::require($ex['actor_id'] === $actor['id'] && $ex['action'] === $action && $ex['fingerprint'] === $fp, 'کلید تکراری با داده متفاوت');
            return json_decode($ex['result'] ?: '{}', true) ?: [];
        }
        Database::begin();
        try {
            $result = $work();
            $db->prepare('INSERT INTO command_receipts (`key`, actor_id, action, fingerprint, result, at) VALUES (?,?,?,?,?,?)')
                ->execute([$key, $actor['id'], $action, $fp, json_encode($result, JSON_UNESCAPED_UNICODE), date('Y-m-d H:i:s')]);
            Database::commit();
            return $result;
        } catch (Throwable $e) {
            Database::rollBack();
            throw $e;
        }
    }

    public static function catalog(array $actor): array
    {
        $db = Database::pdo();
        $ex = self::expiryMap($db);
        $products = array_map(function ($p) use ($ex) {
            $e = $ex[$p['id']] ?? null;
            return [
                'id' => $p['id'],
                'sku' => $p['sku'],
                'name' => $p['name'],
                'unit' => $p['unit'],
                'minimumStock' => (float) $p['minimum_stock'],
                'perishable' => (int) ($p['perishable'] ?? 0) === 1,
                'shelfLifeDays' => isset($p['shelf_life_days']) ? (int) $p['shelf_life_days'] : null,
                'expiryAlertDays' => (int) ($p['expiry_alert_days'] ?? 30),
                'nearestExpiry' => $e['nearest'] ?? null,
                'nearestExpiryShamsi' => !empty($e['nearest']) ? Jalali::formatShamsi($e['nearest']) : null,
                'nearestExpiryDays' => !empty($e['nearest']) ? (int) round((strtotime($e['nearest']) - strtotime(date('Y-m-d'))) / 86400) : null,
                'expiredQty' => (float) ($e['expired'] ?? 0),
            ];
        }, $db->query('SELECT * FROM products ORDER BY name')->fetchAll());
        $levels = $db->query('SELECT * FROM price_levels ORDER BY name')->fetchAll();
        $warehouses = $db->query('SELECT * FROM warehouses ORDER BY name')->fetchAll();
        $prices = $db->query('SELECT product_id AS productId, price_level_id AS priceLevelId, amount FROM product_prices')->fetchAll();
        $stocks = $db->query('SELECT product_id AS productId, warehouse_id AS warehouseId, quantity FROM stocks')->fetchAll();

        if ($actor['role'] === 'Admin') {
            $customers = $db->query('SELECT id, name, phone, address, price_level_id AS priceLevelId, visitor_id AS visitorId, opening_debt AS openingDebt FROM customers ORDER BY name')->fetchAll();
            $visitors = $db->query("SELECT id, name, username FROM users WHERE role='Visitor' AND active=1 ORDER BY name")->fetchAll();
        } else {
            $st = $db->prepare('SELECT id, name, phone, address, price_level_id AS priceLevelId, visitor_id AS visitorId, opening_debt AS openingDebt FROM customers WHERE visitor_id=? ORDER BY name');
            $st->execute([$actor['id']]);
            $customers = $st->fetchAll();
            $visitors = [];
        }
        if ($actor['role'] === 'Admin') {
            $customerPrices = $db->query('SELECT customer_id AS customerId, product_id AS productId, amount FROM customer_prices')->fetchAll();
        } else {
            $st = $db->prepare('SELECT cp.customer_id AS customerId, cp.product_id AS productId, cp.amount FROM customer_prices cp JOIN customers c ON c.id=cp.customer_id WHERE c.visitor_id=?');
            $st->execute([$actor['id']]);
            $customerPrices = $st->fetchAll();
        }
        return compact('products', 'levels', 'warehouses', 'prices', 'stocks', 'customers', 'visitors', 'customerPrices');
    }

    public static function createProduct(array $actor, array $in): array
    {
        Auth::requireAdmin($actor);
        $sku = Rules::text($in['sku'] ?? null, 80);
        $name = Rules::text($in['name'] ?? null);
        $unit = $in['unit'] ?? '';
        Rules::require(in_array($unit, ['kg', 'count'], true), 'واحد نامعتبر است');
        $min = (float) ($in['minimumStock'] ?? 0);
        $id = Rules::uuid();
        [$per, $shelf, $alert] = self::expiryFields($in);
        Database::pdo()->prepare('INSERT INTO products (id, sku, name, unit, minimum_stock, perishable, shelf_life_days, expiry_alert_days) VALUES (?,?,?,?,?,?,?,?)')
            ->execute([$id, $sku, $name, $unit, $min, $per, $shelf, $alert]);
        self::audit($actor, 'ProductCreated', $id);
        return ['id' => $id];
    }

    public static function setPrice(array $actor, array $in): array
    {
        Auth::requireAdmin($actor);
        $pid = $in['productId'] ?? '';
        $lid = $in['priceLevelId'] ?? '';
        $amount = Rules::money($in['amount'] ?? 0);
        $db = Database::pdo();
        if ($db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
            $db->prepare('INSERT OR REPLACE INTO product_prices (product_id, price_level_id, amount) VALUES (?,?,?)')
                ->execute([$pid, $lid, $amount]);
        } else {
            $db->prepare('INSERT INTO product_prices (product_id, price_level_id, amount) VALUES (?,?,?)
                ON DUPLICATE KEY UPDATE amount=VALUES(amount)')->execute([$pid, $lid, $amount]);
        }
        self::audit($actor, 'PriceChanged', $pid, (string) $amount);
        return ['id' => $pid];
    }

    public static function createCustomer(array $actor, array $in): array
    {
        Auth::requireAdmin($actor);
        $name = Rules::text($in['name'] ?? null);
        $level = $in['priceLevelId'] ?? '';
        $opening = Rules::money($in['openingDebt'] ?? 0);
        self::requireRef('price_levels', $level, 'سطح قیمت نامعتبر است');
        if (!empty($in['visitorId'])) self::requireRef('users', $in['visitorId'], 'ویزیتور نامعتبر است');
        $id = Rules::uuid();
        Database::pdo()->prepare('INSERT INTO customers (id, name, phone, address, price_level_id, visitor_id, opening_debt) VALUES (?,?,?,?,?,?,?)')
            ->execute([$id, $name, $in['phone'] ?? null, $in['address'] ?? null, $level, $in['visitorId'] ?? null, $opening]);
        self::audit($actor, 'CustomerCreated', $id);
        return ['id' => $id];
    }

    public static function updateCustomer(array $actor, string $id, array $in): array
    {
        Auth::requireAdmin($actor);
        $name = Rules::text($in['name'] ?? null);
        self::requireRef('customers', $id, 'مشتری یافت نشد');
        self::requireRef('price_levels', $in['priceLevelId'] ?? '', 'سطح قیمت نامعتبر است');
        if (!empty($in['visitorId'])) self::requireRef('users', $in['visitorId'], 'ویزیتور نامعتبر است');
        Database::pdo()->prepare('UPDATE customers SET name=?, phone=?, address=?, price_level_id=?, visitor_id=? WHERE id=?')
            ->execute([$name, $in['phone'] ?? null, $in['address'] ?? null, $in['priceLevelId'] ?? null, $in['visitorId'] ?? null, $id]);
        self::audit($actor, 'CustomerUpdated', $id);
        return ['id' => $id];
    }

    public static function createVisitor(array $actor, array $in): array
    {
        Auth::requireAdmin($actor);
        $username = strtolower(Rules::text($in['username'] ?? null, 80));
        $name = Rules::text($in['name'] ?? null);
        $password = (string) ($in['password'] ?? '');
        Rules::require(mb_strlen($password) >= 12 && mb_strlen($password) <= 200, 'رمز باید بین ۱۲ تا ۲۰۰ نویسه باشد');
        $role = (($in['role'] ?? 'Visitor') === 'Admin') ? 'Admin' : 'Visitor';
        $dup = Database::pdo()->prepare('SELECT COUNT(*) FROM users WHERE username=?');
        $dup->execute([$username]);
        Rules::require((int) $dup->fetchColumn() === 0, 'این نام کاربری قبلاً ثبت شده است');
        $id = Rules::uuid();
        Database::pdo()->prepare('INSERT INTO users (id, username, name, role, password, active, failures) VALUES (?,?,?,?,?,?,0)')
            ->execute([$id, $username, $name, $role, password_hash($password, PASSWORD_DEFAULT), 1]);
        self::audit($actor, 'UserCreated', $id, $role);
        return ['id' => $id];
    }

    public static function createLevel(array $actor, array $in): array
    {
        Auth::requireAdmin($actor);
        $name = Rules::text($in['name'] ?? null, 80);
        $id = Rules::uuid();
        Database::pdo()->prepare('INSERT INTO price_levels (id, name) VALUES (?,?)')->execute([$id, $name]);
        self::audit($actor, 'LevelCreated', $id);
        return ['id' => $id];
    }


    /**
     * مصرف از دسته‌ها به ترتیب نزدیک‌ترین انقضا (FEFO)؛ دسته‌ی منقضی‌شده فروخته نمی‌شود.
     * مقدار بدون دسته (داده‌ی قدیمی) را برمی‌گرداند.
     */
    public static function consumeBatches(PDO $db, string $productId, string $warehouseId, float $qty, ?string $orderId = null, bool $allowExpired = false): float
    {
        Rules::require($qty > 0, 'مقدار مصرف نامعتبر');
        $sql = 'SELECT id, quantity FROM stock_batches WHERE product_id=? AND warehouse_id=? AND depleted_at IS NULL AND quantity>0';
        $args = [$productId, $warehouseId];
        if (!$allowExpired) {
            $sql .= ' AND (expires_on IS NULL OR expires_on >= ?)';
            $args[] = date('Y-m-d');
        }
        $sql .= ' ORDER BY CASE WHEN expires_on IS NULL THEN 1 ELSE 0 END, expires_on ASC, at ASC' . self::lock();
        $st = $db->prepare($sql);
        $st->execute($args);
        $need = $qty;
        foreach ($st->fetchAll() as $b) {
            if ($need <= 0) break;
            $have = (float) $b['quantity'];
            if ($have <= 0) continue;
            $take = min($have, $need);
            $left = round($have - $take, 3);
            $db->prepare('UPDATE stock_batches SET quantity=?, depleted_at=? WHERE id=?')
                ->execute([$left, $left <= 0 ? date('Y-m-d H:i:s') : null, $b['id']]);
            if ($orderId !== null) {
                $up = $db->prepare('UPDATE batch_allocations SET quantity=quantity+? WHERE order_id=? AND batch_id=?');
                $up->execute([$take, $orderId, $b['id']]);
                if ($up->rowCount() === 0) {
                    $db->prepare('INSERT INTO batch_allocations (order_id, batch_id, quantity) VALUES (?,?,?)')->execute([$orderId, $b['id'], $take]);
                }
            }
            $need = round($need - $take, 3);
        }
        return max(0.0, $need);
    }

    /** موجودی قابل فروش (غیرمنقضی) و مقدار منقضی‌شده */
    public static function usableQty(PDO $db, string $productId, string $warehouseId, float $stockQty): array
    {
        $st = $db->prepare('SELECT COALESCE(SUM(quantity),0) FROM stock_batches WHERE product_id=? AND warehouse_id=? AND depleted_at IS NULL AND expires_on IS NOT NULL AND expires_on < ?');
        $st->execute([$productId, $warehouseId, date('Y-m-d')]);
        $expired = (float) $st->fetchColumn();
        return [max(0.0, round($stockQty - $expired, 3)), $expired];
    }

    /** هر ورود = یک دسته‌ی جدید؛ اختلاف انقضا با دسته‌ی قبلی همان کالا/انبار ذخیره می‌شود */
    public static function addBatch(PDO $db, string $productId, string $warehouseId, float $qty, ?string $expiresOn, ?string $movementId, ?string $lotNo = null): array
    {
        $st = $db->prepare('SELECT id, expires_on FROM stock_batches WHERE product_id=? AND warehouse_id=? ORDER BY at DESC, id DESC LIMIT 1');
        $st->execute([$productId, $warehouseId]);
        $prev = $st->fetch() ?: null;
        $diff = null;
        if ($prev && !empty($prev['expires_on']) && $expiresOn) {
            $diff = (int) round((strtotime($expiresOn) - strtotime($prev['expires_on'])) / 86400);
        }
        $id = Rules::uuid();
        $db->prepare('INSERT INTO stock_batches (id, product_id, warehouse_id, quantity, expires_on, movement_id, at, lot_no, prev_batch_id, diff_days, initial_qty) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([$id, $productId, $warehouseId, $qty, $expiresOn, $movementId, date('Y-m-d H:i:s'), $lotNo, $prev['id'] ?? null, $diff, $qty]);
        return ['id' => $id, 'prevExpiresOn' => $prev['expires_on'] ?? null, 'diffDays' => $diff];
    }

    public static function expiryFields(array $in): array
    {
        $per = in_array($in['perishable'] ?? 0, [1, '1', true, 'true'], true) ? 1 : 0;
        $shelf = (isset($in['shelfLifeDays']) && $in['shelfLifeDays'] !== '' && (int) $in['shelfLifeDays'] > 0) ? min(3650, (int) $in['shelfLifeDays']) : null;
        $alert = (isset($in['expiryAlertDays']) && (int) $in['expiryAlertDays'] > 0) ? min(365, (int) $in['expiryAlertDays']) : 30;
        return [$per, $shelf, $alert];
    }

    public static function expiryMap(PDO $db): array
    {
        $st = $db->prepare('SELECT product_id, MIN(expires_on) AS nearest, SUM(CASE WHEN expires_on IS NOT NULL AND expires_on < ? THEN quantity ELSE 0 END) AS expired FROM stock_batches WHERE depleted_at IS NULL AND quantity>0 GROUP BY product_id');
        $st->execute([date('Y-m-d')]);
        $out = [];
        foreach ($st->fetchAll() as $r) {
            $out[$r['product_id']] = ['nearest' => $r['nearest'], 'expired' => $r['expired']];
        }
        return $out;
    }

    public static function expirySummary(): array
    {
        $db = Database::pdo();
        $today = date('Y-m-d');
        $st = $db->prepare('SELECT COUNT(*) FROM stock_batches WHERE depleted_at IS NULL AND quantity>0 AND expires_on IS NOT NULL AND expires_on < ?');
        $st->execute([$today]);
        $expired = (int) $st->fetchColumn();
        $st = $db->prepare('SELECT COUNT(*) FROM stock_batches b JOIN products p ON p.id=b.product_id WHERE b.depleted_at IS NULL AND b.quantity>0 AND b.expires_on IS NOT NULL AND b.expires_on >= ? AND b.expires_on <= ?');
        $st->execute([$today, date('Y-m-d', time() + 30 * 86400)]);
        return ['expired' => $expired, 'soon' => (int) $st->fetchColumn()];
    }

    /** خط زمانی دسته‌های یک کالا با مقایسه‌ی انقضای هر بار با بار قبلی */
    public static function productBatches(string $productId): array
    {
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM products WHERE id=?');
        $st->execute([$productId]);
        $p = $st->fetch();
        Rules::require((bool) $p, 'کالا یافت نشد', 404);
        $st = $db->prepare('SELECT b.*, w.name AS wname FROM stock_batches b JOIN warehouses w ON w.id=b.warehouse_id WHERE b.product_id=? ORDER BY b.at ASC, b.id ASC');
        $st->execute([$productId]);
        $all = $st->fetchAll();
        $byId = [];
        foreach ($all as $b) $byId[$b['id']] = $b;
        $today = strtotime(date('Y-m-d'));
        $alert = (int) ($p['expiry_alert_days'] ?? 30);
        $rows = [];
        $active = 0.0; $expiredQty = 0.0; $nearest = null;
        foreach ($all as $b) {
            $qty = (float) $b['quantity'];
            $done = !empty($b['depleted_at']) || $qty <= 0;
            $left = !empty($b['expires_on']) ? (int) round((strtotime($b['expires_on']) - $today) / 86400) : null;
            if ($done) $status = 'تمام‌شده';
            elseif ($left === null) $status = 'بدون انقضا';
            elseif ($left < 0) $status = 'منقضی';
            elseif ($left <= 7) $status = 'فوری';
            elseif ($left <= $alert) $status = 'نزدیک';
            else $status = 'سالم';
            if (!$done) {
                $active += $qty;
                if ($left !== null && $left < 0) $expiredQty += $qty;
                if (!empty($b['expires_on']) && ($nearest === null || $b['expires_on'] < $nearest)) $nearest = $b['expires_on'];
            }
            $prev = $byId[$b['prev_batch_id'] ?? ''] ?? null;
            $rows[] = [
                'id' => $b['id'],
                'lotNo' => $b['lot_no'],
                'warehouse' => $b['wname'],
                'receivedAtShamsi' => Jalali::formatShamsi(substr($b['at'], 0, 10)),
                'initialQty' => (float) ($b['initial_qty'] ?? $b['quantity']),
                'quantity' => $qty,
                'expiresOnShamsi' => Jalali::formatShamsi($b['expires_on']),
                'daysLeft' => $left,
                'prevExpiresOnShamsi' => $prev ? Jalali::formatShamsi($prev['expires_on']) : null,
                'diffDays' => isset($b['diff_days']) ? (int) $b['diff_days'] : null,
                'status' => $status,
            ];
        }
        return [
            'productId' => $productId,
            'name' => $p['name'],
            'perishable' => (int) $p['perishable'] === 1,
            'shelfLifeDays' => isset($p['shelf_life_days']) ? (int) $p['shelf_life_days'] : null,
            'activeQty' => round($active, 3),
            'expiredQty' => round($expiredQty, 3),
            'nearestExpiryShamsi' => $nearest ? Jalali::formatShamsi($nearest) : null,
            'batches' => array_reverse($rows),
        ];
    }

    public static function writeOffBatch(array $actor, string $batchId, array $in): array
    {
        Auth::requireAdmin($actor);
        $key = $in['key'] ?? Rules::uuid();
        return self::idempotent($actor, $key, 'WriteOffBatch', array_merge($in, ['batchId' => $batchId]), function () use ($actor, $batchId, $in) {
            $db = Database::pdo();
            $st = $db->prepare('SELECT * FROM stock_batches WHERE id=?' . self::lock());
            $st->execute([$batchId]);
            $b = $st->fetch();
            Rules::require((bool) $b && empty($b['depleted_at']) && (float) $b['quantity'] > 0, 'دسته‌ی فعالی با موجودی یافت نشد', 404);
            $qty = (float) $b['quantity'];
            $st = $db->prepare('SELECT quantity FROM stocks WHERE product_id=? AND warehouse_id=?' . self::lock());
            $st->execute([$b['product_id'], $b['warehouse_id']]);
            $cur = (float) ($st->fetchColumn() ?: 0);
            $db->prepare('UPDATE stocks SET quantity=? WHERE product_id=? AND warehouse_id=?')
                ->execute([max(0, round($cur - $qty, 3)), $b['product_id'], $b['warehouse_id']]);
            $mov = Rules::uuid();
            $db->prepare('INSERT INTO movements (id, product_id, warehouse_id, delta, source_id, reason, at) VALUES (?,?,?,?,?,?,?)')
                ->execute([$mov, $b['product_id'], $b['warehouse_id'], -1 * $qty, $batchId, 'ضایعات: ' . Rules::text($in['reason'] ?? 'منقضی‌شده', 150), date('Y-m-d H:i:s')]);
            $db->prepare('UPDATE stock_batches SET quantity=0, depleted_at=? WHERE id=?')->execute([date('Y-m-d H:i:s'), $batchId]);
            self::audit($actor, 'BatchWrittenOff', $batchId, (string) $qty);
            return ['id' => $batchId, 'quantity' => $qty];
        });
    }

    public static function adjustStock(array $actor, array $in): array
    {
        Auth::requireAdmin($actor);
        $key = $in['key'] ?? Rules::uuid();
        return self::idempotent($actor, $key, 'AdjustStock', $in, function () use ($actor, $in) {
            $db = Database::pdo();
            $st = $db->prepare('SELECT * FROM products WHERE id=?');
            $st->execute([$in['productId'] ?? '']);
            $product = $st->fetch();
            Rules::require((bool) $product, 'کالا یافت نشد');
            self::requireRef('warehouses', $in['warehouseId'] ?? '', 'انبار نامعتبر است');
            $delta = (float) ($in['delta'] ?? 0);
            Rules::require($delta != 0, 'مقدار تغییر موجودی صفر است');
            Rules::quantity($product['unit'], abs($delta));

            $st = $db->prepare('SELECT * FROM stocks WHERE product_id=? AND warehouse_id=?');
            $st->execute([$product['id'], $in['warehouseId']]);
            $stock = $st->fetch();
            $current = (float) ($stock['quantity'] ?? 0);
            $newQty = round($current + $delta, 3);
            Rules::require($newQty >= 0, 'موجودی نمی‌تواند منفی شود');

            $expiresOn = null;
            if (!empty($in['expiresOn']) || !empty($in['expires_on'])) {
                $expiresOn = Jalali::parseShamsi($in['expiresOn'] ?? $in['expires_on'] ?? null);
            }
            // فقط هنگام ورود کالا تاریخ انقضا معنا دارد
            if ($delta < 0 && $expiresOn) {
                throw new RuleException('تاریخ انقضا فقط برای ورود کالا ثبت می‌شود');
            }
            $lot = (isset($in['lotNo']) && trim((string) $in['lotNo']) !== '') ? Rules::text($in['lotNo'], 60) : null;
            if ($delta > 0) {
                if ((int) ($product['perishable'] ?? 0) === 1) {
                    Rules::require($expiresOn !== null, 'برای «' . $product['name'] . '» تاریخ انقضا الزامی است');
                }
                if ($expiresOn !== null) {
                    Rules::require($expiresOn >= date('Y-m-d'), 'تاریخ انقضا نباید گذشته باشد');
                }
            }

            if ($stock) {
                $db->prepare('UPDATE stocks SET quantity=? WHERE product_id=? AND warehouse_id=?')
                    ->execute([$newQty, $product['id'], $in['warehouseId']]);
            } else {
                $db->prepare('INSERT INTO stocks (product_id, warehouse_id, quantity) VALUES (?,?,?)')
                    ->execute([$product['id'], $in['warehouseId'], $newQty]);
            }
            $movId = Rules::uuid();
            $db->prepare('INSERT INTO movements (id, product_id, warehouse_id, delta, source_id, reason, at) VALUES (?,?,?,?,?,?,?)')
                ->execute([$movId, $product['id'], $in['warehouseId'], $delta, $movId, Rules::text($in['reason'] ?? 'اصلاح موجودی', 200), date('Y-m-d H:i:s')]);

            $warnings = [];
            $batch = null;
            if ($delta > 0) {
                // هر ورود = دسته جدید با تاریخ انقضای خودش (با قبلی قاطی نمی‌شود)
                $batch = self::addBatch($db, $product['id'], $in['warehouseId'], $delta, $expiresOn, $movId, $lot);
                if ($batch['diffDays'] !== null) {
                    $d = $batch['diffDays'];
                    $prevS = Jalali::formatShamsi($batch['prevExpiresOn']);
                    if ($d < 0) {
                        $warnings[] = 'انقضای این بار ' . abs($d) . ' روز زودتر از بار قبلی (' . $prevS . ') است؛ در فروش، این دسته اول خارج می‌شود.';
                    } else {
                        $warnings[] = 'انقضای این بار ' . $d . ' روز بعد از بار قبلی (' . $prevS . ') است.';
                    }
                }
                $shelf = (int) ($product['shelf_life_days'] ?? 0);
                if ($shelf > 0 && $expiresOn) {
                    $remain = (int) round((strtotime($expiresOn) - strtotime(date('Y-m-d'))) / 86400);
                    if ($remain < $shelf / 2) {
                        $warnings[] = 'عمر باقی‌مانده‌ی این بار فقط ' . $remain . ' روز از ' . $shelf . ' روز عمر مفید است.';
                    }
                }
            } else {
                self::consumeBatches($db, $product['id'], $in['warehouseId'], abs($delta), null, true);
            }

            self::audit($actor, 'StockAdjusted', $product['id'], (string) $delta);
            return [
                'id' => $movId,
                'expiresOn' => $expiresOn ? Jalali::formatShamsi($expiresOn) : null,
                'warnings' => $warnings,
                'diffDays' => $batch['diffDays'] ?? null,
            ];
        });
    }

    public static function submitOrder(array $actor, array $in): array
    {
        $key = $in['key'] ?? Rules::uuid();
        return self::idempotent($actor, $key, 'SubmitOrder', $in, function () use ($actor, $in) {
            $db = Database::pdo();
            $st = $db->prepare('SELECT * FROM customers WHERE id=?');
            $st->execute([$in['customerId'] ?? '']);
            $customer = $st->fetch();
            Rules::require((bool) $customer, 'مشتری یافت نشد');
            if ($actor['role'] !== 'Admin') {
                Rules::require($customer['visitor_id'] === $actor['id'], 'دسترسی به این مشتری ندارید', 403);
            }
            $linesIn = $in['lines'] ?? [];
            Rules::require(is_array($linesIn) && count($linesIn) > 0 && count($linesIn) <= 200, 'حداقل یک قلم کالا لازم است');
            self::requireRef('warehouses', $in['warehouseId'] ?? '', 'انبار نامعتبر است');

            $sum = 0;
            $prepared = [];
            foreach ($linesIn as $line) {
                $st = $db->prepare('SELECT * FROM products WHERE id=?');
                $st->execute([$line['productId'] ?? '']);
                $p = $st->fetch();
                Rules::require((bool) $p, 'کالا یافت نشد');
                $price = self::resolvePrice($actor, $customer, $p, (array) $line);
                $total = (float) Rules::lineTotal($p['unit'], $line['quantity'] ?? 0, $price);
                $sum += $total;
                $prepared[] = [$p, (float) $line['quantity'], Rules::money($price), Rules::money($total)];
            }
            $discount = (float) ($in['discount'] ?? 0);
            Rules::require($discount >= 0 && $discount <= $sum, 'تخفیف نامعتبر');
            if ($actor['role'] !== 'Admin') {
                $cap = (float) (Config::load()['visitor_max_discount_pct'] ?? 5);
                Rules::require($discount <= $sum * $cap / 100, 'تخفیف بیش از سقف مجاز ویزیتور است');
            }
            $discount = (float) Rules::money($discount);

            $orderId = Rules::uuid();
            $status = $actor['role'] === 'Admin' ? 'Approved' : 'Submitted';
            $db->prepare('INSERT INTO orders (id, customer_id, warehouse_id, creator_id, channel, status, discount, at) VALUES (?,?,?,?,?,?,?,?)')
                ->execute([$orderId, $customer['id'], $in['warehouseId'], $actor['id'], $actor['role'] === 'Admin' ? (in_array($in['channel'] ?? '', ['حضوری', 'تلفنی', 'ویزیتور'], true) ? $in['channel'] : 'حضوری') : 'ویزیتور', $status, $discount, date('Y-m-d H:i:s')]);

            foreach ($prepared as [$p, $qty, $price, $total]) {
                $db->prepare('INSERT INTO order_lines (id, order_id, product_id, name, unit, quantity, price, total) VALUES (?,?,?,?,?,?,?,?)')
                    ->execute([Rules::uuid(), $orderId, $p['id'], $p['name'], $p['unit'], $qty, $price, $total]);
            }

            if ($status === 'Approved') {
                self::issueInvoice($actor, $orderId);
            }
            self::audit($actor, 'OrderSubmitted', $orderId);
            return ['id' => $orderId];
        });
    }

    public static function approveOrder(array $actor, string $orderId, array $in): array
    {
        Auth::requireAdmin($actor);
        $key = $in['key'] ?? Rules::uuid();
        return self::idempotent($actor, $key, 'ApproveOrder', array_merge($in, ['orderId' => $orderId]), function () use ($actor, $orderId) {
            $db = Database::pdo();
            $st = $db->prepare('SELECT * FROM orders WHERE id=?');
            $st->execute([$orderId]);
            $order = $st->fetch();
            Rules::require((bool) $order && $order['status'] === 'Submitted', 'سفارش قابل تأیید نیست');
            $db->prepare("UPDATE orders SET status='Approved' WHERE id=?")->execute([$orderId]);
            self::issueInvoice($actor, $orderId);
            self::audit($actor, 'OrderApproved', $orderId);
            return ['id' => $orderId];
        });
    }

    private static function issueInvoice(array $actor, string $orderId): string
    {
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM orders WHERE id=?');
        $st->execute([$orderId]);
        $order = $st->fetch();
        $lines = $db->prepare('SELECT * FROM order_lines WHERE order_id=?');
        $lines->execute([$orderId]);
        $lines = $lines->fetchAll();
        $sum = 0;
        foreach ($lines as $l) {
            $sum += (float) $l['total'];
        }
        $total = Rules::money($sum - (float) $order['discount']);

        foreach ($lines as $line) {
            $st = $db->prepare('SELECT quantity FROM stocks WHERE product_id=? AND warehouse_id=?' . self::lock());
            $st->execute([$line['product_id'], $order['warehouse_id']]);
            $qty = (float) ($st->fetchColumn() ?: 0);
            Rules::require($qty >= (float) $line['quantity'], "موجودی «{$line['name']}» کافی نیست");
            [$usable, $expiredQty] = self::usableQty($db, $line['product_id'], $order['warehouse_id'], $qty);
            Rules::require($usable >= (float) $line['quantity'], "موجودی غیرمنقضی «{$line['name']}» کافی نیست (منقضی‌شده در انبار: " . $expiredQty . ')');
            $newQty = round($qty - (float) $line['quantity'], 3);
            $db->prepare('UPDATE stocks SET quantity=? WHERE product_id=? AND warehouse_id=?')
                ->execute([$newQty, $line['product_id'], $order['warehouse_id']]);
            $db->prepare('INSERT INTO movements (id, product_id, warehouse_id, delta, source_id, reason, at) VALUES (?,?,?,?,?,?,?)')
                ->execute([Rules::uuid(), $line['product_id'], $order['warehouse_id'], -1 * (float) $line['quantity'], $orderId, 'فروش', date('Y-m-d H:i:s')]);
            self::consumeBatches($db, $line['product_id'], $order['warehouse_id'], (float) $line['quantity'], $orderId, false);
        }

        $number = self::nextNumber('invoices');
        $invId = Rules::uuid();
        $db->prepare('INSERT INTO invoices (id, order_id, number, total, status, at) VALUES (?,?,?,?,?,?)')
            ->execute([$invId, $orderId, $number, $total, 'Posted', date('Y-m-d H:i:s')]);
        $db->prepare("UPDATE orders SET status='Invoiced' WHERE id=?")->execute([$orderId]);
        self::audit($actor, 'InvoiceIssued', $invId, (string) $number);
        return $invId;
    }

    public static function receive(array $actor, string $invoiceId, array $in): array
    {
        Auth::requireAdmin($actor);
        $key = $in['key'] ?? Rules::uuid();
        $payment = $in['payment'] ?? $in;
        return self::idempotent($actor, $key, 'Receive', array_merge($in, ['invoiceId' => $invoiceId]), function () use ($actor, $invoiceId, $payment) {
            Rules::payment($payment);
            $db = Database::pdo();
            $st = $db->prepare('SELECT i.*, o.customer_id FROM invoices i JOIN orders o ON o.id=i.order_id WHERE i.id=?' . self::lock());
            $st->execute([$invoiceId]);
            $inv = $st->fetch();
            Rules::require((bool) $inv && $inv['status'] === 'Posted', 'فاکتور قابل دریافت نیست');
            $st = $db->prepare("SELECT COALESCE(SUM(p.amount),0) FROM payments p LEFT JOIN checks c ON c.payment_id=p.id WHERE p.invoice_id=? AND (c.id IS NULL OR c.status!='Returned')");
            $st->execute([$invoiceId]);
            $remaining = (float) $inv['total'] - (float) $st->fetchColumn();
            Rules::require((float) Rules::money($payment['amount']) <= $remaining + 0.5, 'مبلغ دریافت از مانده‌ی فاکتور بیشتر است (مانده: ' . number_format(max(0, $remaining)) . ')');
            $payId = Rules::uuid();
            $db->prepare('INSERT INTO payments (id, invoice_id, customer_id, method, amount, reference, at) VALUES (?,?,?,?,?,?,?)')
                ->execute([$payId, $invoiceId, $inv['customer_id'], $payment['method'], Rules::money($payment['amount']), $payment['reference'] ?? null, date('Y-m-d H:i:s')]);
            if ($payment['method'] === 'Check') {
                $db->prepare('INSERT INTO checks (id, payment_id, bank, number, due, amount, status) VALUES (?,?,?,?,?,?,?)')
                    ->execute([Rules::uuid(), $payId, $payment['bank'], $payment['number'], $payment['due'], Rules::money($payment['amount']), 'Pending']);
            }
            self::audit($actor, 'PaymentReceived', $payId);
            return ['id' => $payId];
        });
    }

    public static function voidInvoice(array $actor, string $invoiceId, array $in): array
    {
        Auth::requireAdmin($actor);
        $key = $in['key'] ?? Rules::uuid();
        return self::idempotent($actor, $key, 'VoidInvoice', array_merge($in, ['invoiceId' => $invoiceId]), function () use ($actor, $invoiceId, $in) {
            $db = Database::pdo();
            $st = $db->prepare('SELECT * FROM invoices WHERE id=?');
            $st->execute([$invoiceId]);
            $inv = $st->fetch();
            Rules::require((bool) $inv && $inv['status'] === 'Posted', 'فاکتور قابل ابطال نیست');
            $pc = $db->prepare('SELECT COUNT(*) FROM payments WHERE invoice_id=?');
            $pc->execute([$invoiceId]);
            Rules::require((int) $pc->fetchColumn() === 0, 'فاکتور دارای دریافت قابل ابطال مستقیم نیست');

            $st = $db->prepare('SELECT * FROM orders WHERE id=?');
            $st->execute([$inv['order_id']]);
            $order = $st->fetch();
            $lines = $db->prepare('SELECT * FROM order_lines WHERE order_id=?');
            $lines->execute([$inv['order_id']]);
            foreach ($lines->fetchAll() as $line) {
                $st = $db->prepare('SELECT quantity FROM stocks WHERE product_id=? AND warehouse_id=?' . self::lock());
                $st->execute([$line['product_id'], $order['warehouse_id']]);
                $qty = (float) ($st->fetchColumn() ?: 0);
                $newQty = round($qty + (float) $line['quantity'], 3);
                $ex = $db->prepare('SELECT 1 FROM stocks WHERE product_id=? AND warehouse_id=?');
                $ex->execute([$line['product_id'], $order['warehouse_id']]);
                if ($ex->fetch()) {
                    $db->prepare('UPDATE stocks SET quantity=? WHERE product_id=? AND warehouse_id=?')
                        ->execute([$newQty, $line['product_id'], $order['warehouse_id']]);
                } else {
                    $db->prepare('INSERT INTO stocks (product_id, warehouse_id, quantity) VALUES (?,?,?)')
                        ->execute([$line['product_id'], $order['warehouse_id'], $newQty]);
                }
                $db->prepare('INSERT INTO movements (id, product_id, warehouse_id, delta, source_id, reason, at) VALUES (?,?,?,?,?,?,?)')
                    ->execute([Rules::uuid(), $line['product_id'], $order['warehouse_id'], (float) $line['quantity'], $invoiceId, 'ابطال: ' . ($in['reason'] ?? ''), date('Y-m-d H:i:s')]);
            }
            $al = $db->prepare('SELECT batch_id, quantity FROM batch_allocations WHERE order_id=?');
            $al->execute([$inv['order_id']]);
            foreach ($al->fetchAll() as $a) {
                $db->prepare('UPDATE stock_batches SET quantity=quantity+?, depleted_at=NULL WHERE id=?')->execute([$a['quantity'], $a['batch_id']]);
            }
            $db->prepare("UPDATE invoices SET status='Voided' WHERE id=?")->execute([$invoiceId]);
            $db->prepare("UPDATE orders SET status='Cancelled' WHERE id=?")->execute([$inv['order_id']]);
            self::audit($actor, 'InvoiceVoided', $invoiceId, $in['reason'] ?? null);
            return ['id' => $invoiceId];
        });
    }

    public static function changeCheck(array $actor, string $checkId, array $in): array
    {
        Auth::requireAdmin($actor);
        $key = $in['key'] ?? Rules::uuid();
        return self::idempotent($actor, $key, 'ChangeCheck', array_merge($in, ['checkId' => $checkId]), function () use ($actor, $checkId, $in) {
            $status = $in['status'] ?? '';
            Rules::require(in_array($status, ['Collected', 'Returned'], true), 'وضعیت نامعتبر');
            $db = Database::pdo();
            $st = $db->prepare('SELECT * FROM checks WHERE id=?');
            $st->execute([$checkId]);
            $c = $st->fetch();
            Rules::require((bool) $c && $c['status'] === 'Pending', 'چک قبلاً تعیین تکلیف شده');
            $db->prepare('UPDATE checks SET status=? WHERE id=?')->execute([$status, $checkId]);
            self::audit($actor, 'Check' . $status, $checkId);
            return ['id' => $checkId];
        });
    }

    public static function balance(string $customerId): array
    {
        $db = Database::pdo();
        $st = $db->prepare('SELECT opening_debt FROM customers WHERE id=?');
        $st->execute([$customerId]);
        $opening = (float) ($st->fetchColumn() ?: 0);
        $st = $db->prepare("SELECT COALESCE(SUM(i.total),0) FROM invoices i JOIN orders o ON o.id=i.order_id WHERE i.status='Posted' AND o.customer_id=?");
        $st->execute([$customerId]);
        $invoiced = (float) $st->fetchColumn();
        $st = $db->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE customer_id=? AND method!='Check'");
        $st->execute([$customerId]);
        $paidCash = (float) $st->fetchColumn();
        $st = $db->prepare("SELECT COALESCE(SUM(c.amount),0) FROM checks c JOIN payments p ON p.id=c.payment_id WHERE p.customer_id=? AND c.status='Collected'");
        $st->execute([$customerId]);
        $paidChecks = (float) $st->fetchColumn();
        $st = $db->prepare('SELECT COALESCE(SUM(amount),0) FROM opening_receipts WHERE customer_id=?');
        $st->execute([$customerId]);
        $openingPaid = (float) $st->fetchColumn();
        $collected = $paidCash + $paidChecks + $openingPaid;
        return [
            'openingDebt' => $opening,
            'invoiced' => $invoiced,
            'collected' => $collected,
            'balance' => (float) Rules::money($opening + $invoiced - $collected),
        ];
    }

    public static function receiveOpening(array $actor, string $customerId, array $in): array
    {
        Auth::requireAdmin($actor);
        $key = $in['key'] ?? Rules::uuid();
        $payment = $in['payment'] ?? $in;
        return self::idempotent($actor, $key, 'ReceiveOpening', array_merge($in, ['customerId' => $customerId]), function () use ($actor, $customerId, $payment) {
            Rules::require(($payment['method'] ?? '') !== 'Check', 'چک برای مانده اول دوره پشتیبانی نمی‌شود');
            Rules::payment($payment);
            $db = Database::pdo();
            $st = $db->prepare('SELECT opening_debt FROM customers WHERE id=?');
            $st->execute([$customerId]);
            $od = $st->fetchColumn();
            Rules::require($od !== false, 'مشتری یافت نشد', 404);
            $st = $db->prepare('SELECT COALESCE(SUM(amount),0) FROM opening_receipts WHERE customer_id=?');
            $st->execute([$customerId]);
            Rules::require((float) Rules::money($payment['amount']) <= (float) $od - (float) $st->fetchColumn() + 0.5, 'مبلغ از مانده‌ی اول دوره بیشتر است');
            $id = Rules::uuid();
            Database::pdo()->prepare('INSERT INTO opening_receipts (id, customer_id, amount, method, reference, at) VALUES (?,?,?,?,?,?)')
                ->execute([$id, $customerId, Rules::money($payment['amount']), $payment['method'], $payment['reference'] ?? null, date('Y-m-d H:i:s')]);
            self::audit($actor, 'OpeningReceived', $id);
            return ['id' => $id];
        });
    }

    // ---------- ابزارهای جدید ----------
    public static function lock(): string
    {
        return Database::pdo()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite' ? '' : ' FOR UPDATE';
    }

    /** شماره‌ی پشت‌سرهم و بدون تکرار حتی با درخواست هم‌زمان */
    public static function nextNumber(string $name): int
    {
        $db = Database::pdo();
        if ($db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
            $db->prepare('UPDATE counters SET value=value+1 WHERE name=?')->execute([$name]);
            $st = $db->prepare('SELECT value FROM counters WHERE name=?');
            $st->execute([$name]);
            return (int) $st->fetchColumn();
        }
        $db->prepare('UPDATE counters SET value=LAST_INSERT_ID(value+1) WHERE name=?')->execute([$name]);
        return (int) $db->query('SELECT LAST_INSERT_ID()')->fetchColumn();
    }

    public static function requireRef(string $table, $id, string $msg): void
    {
        if (!in_array($table, ['users', 'customers', 'warehouses', 'price_levels', 'products'], true)) {
            throw new RuntimeException('bad table');
        }
        $st = Database::pdo()->prepare("SELECT COUNT(*) FROM {$table} WHERE id=?");
        $st->execute([(string) $id]);
        Rules::require((int) $st->fetchColumn() > 0, $msg);
    }

    /** قیمت را سرور تعیین می‌کند: قیمت ویژه‌ی مشتری، سپس سطح قیمت. فقط مدیر می‌تواند قیمت دستی بدهد. */
    public static function resolvePrice(array $actor, array $customer, array $product, array $line)
    {
        $db = Database::pdo();
        $st = $db->prepare('SELECT amount FROM customer_prices WHERE customer_id=? AND product_id=?');
        $st->execute([$customer['id'], $product['id']]);
        $v = $st->fetchColumn();
        if ($v === false) {
            $st = $db->prepare('SELECT amount FROM product_prices WHERE product_id=? AND price_level_id=?');
            $st->execute([$product['id'], $customer['price_level_id']]);
            $v = $st->fetchColumn();
        }
        if ($actor['role'] === 'Admin' && isset($line['price']) && is_numeric($line['price'])) {
            return $line['price'];
        }
        Rules::require($v !== false, 'برای «' . $product['name'] . '» قیمتی تعریف نشده است');
        return $v;
    }

    public static function assertCustomerAccess(array $actor, string $customerId): array
    {
        $st = Database::pdo()->prepare('SELECT * FROM customers WHERE id=?');
        $st->execute([$customerId]);
        $c = $st->fetch();
        Rules::require((bool) $c, 'مشتری یافت نشد', 404);
        if ($actor['role'] !== 'Admin') {
            Rules::require(($c['visitor_id'] ?? null) === $actor['id'], 'دسترسی ندارید', 403);
        }
        return $c;
    }

    public static function assertOrderAccess(array $actor, array $order): void
    {
        if ($actor['role'] === 'Admin' || $order['creator_id'] === $actor['id']) return;
        self::assertCustomerAccess($actor, $order['customer_id']);
    }

    public static function updateProduct(array $actor, string $id, array $in): array
    {
        Auth::requireAdmin($actor);
        self::requireRef('products', $id, 'کالا یافت نشد');
        $sku = Rules::text($in['sku'] ?? null, 80);
        $name = Rules::text($in['name'] ?? null);
        Rules::require(in_array($in['unit'] ?? '', ['kg', 'count'], true), 'واحد نامعتبر است');
        $min = max(0, (float) ($in['minimumStock'] ?? 0));
        [$per, $shelf, $alert] = self::expiryFields($in);
        Database::pdo()->prepare('UPDATE products SET sku=?, name=?, unit=?, minimum_stock=?, perishable=?, shelf_life_days=?, expiry_alert_days=? WHERE id=?')
            ->execute([$sku, $name, $in['unit'], $min, $per, $shelf, $alert, $id]);
        self::audit($actor, 'ProductUpdated', $id);
        return ['id' => $id];
    }

    public static function rejectOrder(array $actor, string $orderId): array
    {
        Auth::requireAdmin($actor);
        $db = Database::pdo();
        $st = $db->prepare('SELECT status FROM orders WHERE id=?');
        $st->execute([$orderId]);
        Rules::require($st->fetchColumn() === 'Submitted', 'فقط سفارش در انتظار تأیید قابل رد است');
        $db->prepare("UPDATE orders SET status='Cancelled' WHERE id=?")->execute([$orderId]);
        self::audit($actor, 'OrderRejected', $orderId);
        return ['id' => $orderId];
    }

    public static function setUserActive(array $actor, string $id, bool $active): array
    {
        Auth::requireAdmin($actor);
        Rules::require($active || $id !== $actor['id'], 'حساب خودتان را نمی‌توانید غیرفعال کنید');
        $db = Database::pdo();
        $db->prepare('UPDATE users SET active=? WHERE id=?')->execute([$active ? 1 : 0, $id]);
        if (!$active) $db->prepare('DELETE FROM sessions WHERE user_id=?')->execute([$id]);
        self::audit($actor, $active ? 'UserEnabled' : 'UserDisabled', $id);
        return ['ok' => true];
    }

    public static function resetPassword(array $actor, string $id, array $in): array
    {
        Auth::requireAdmin($actor);
        $pw = (string) ($in['password'] ?? '');
        Rules::require(mb_strlen($pw) >= 12 && mb_strlen($pw) <= 200, 'رمز باید بین ۱۲ تا ۲۰۰ نویسه باشد');
        self::requireRef('users', $id, 'کاربر یافت نشد');
        $db = Database::pdo();
        $db->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($pw, PASSWORD_DEFAULT), $id]);
        $db->prepare('DELETE FROM sessions WHERE user_id=?')->execute([$id]);
        self::audit($actor, 'PasswordReset', $id);
        return ['ok' => true];
    }

    public static function lowStock(): array
    {
        $rows = Database::pdo()->query('SELECT p.name, p.unit, p.minimum_stock, COALESCE(SUM(s.quantity),0) AS q FROM products p LEFT JOIN stocks s ON s.product_id=p.id GROUP BY p.id, p.name, p.unit, p.minimum_stock')->fetchAll();
        $out = [];
        foreach ($rows as $r) {
            if ((float) $r['q'] <= (float) $r['minimum_stock']) {
                $out[] = ['name' => $r['name'], 'unit' => $r['unit'], 'quantity' => (float) $r['q'], 'minimumStock' => (float) $r['minimum_stock']];
            }
        }
        return $out;
    }
}
