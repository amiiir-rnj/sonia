<?php
/**
 * توصیه: این فایل را با نام sonia-config.php یک پوشه بالاتر از public_html بگذارید.
 * مشخصات اتصال را اینجا پر کنید و فایل را به config.php تغییر نام دهید.
 * روی cPanel معمولاً از MySQL Databases این مقادیر را می‌گیرید.
 */
return [
    // mysql یا sqlite
    'db_driver'   => 'mysql',

    // --- MySQL (پیشنهادی برای cPanel) ---
    'db_host'     => 'localhost',
    'db_name'     => 'username_sonia',
    'db_user'     => 'username_sonia',
    'db_pass'     => 'YOUR_PASSWORD',
    'db_charset'  => 'utf8mb4',

    // --- SQLite (اگر MySQL نخواستید؛ فایل در پوشه data ساخته می‌شود) ---
    // 'db_driver' => 'sqlite',
    // 'sqlite_path' => __DIR__ . '/data/sonia.sqlite',

    // آدرس سایت بدون اسلش پایانی
    'app_url'     => 'https://your-domain.com',

    // کلید راه‌اندازی (حتماً یک مقدار تصادفی بلند): برای install.php و ساخت اولین مدیر لازم است
    'setup_key'   => 'CHANGE_ME_TO_A_LONG_RANDOM_STRING',

    // سقف تخفیف ویزیتور (درصد از جمع فاکتور)
    'visitor_max_discount_pct' => 5,

    // در حالت عادی false بگذارید
    'debug'       => false,
];
