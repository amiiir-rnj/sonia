<?php
/**
 * سونیا — API خالص PHP
 * همه درخواست‌های /api/* به اینجا می‌رسند.
 */
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');
header('X-Frame-Options: DENY');
header('Referrer-Policy: same-origin');

$root = dirname(__DIR__);
require_once $root . '/src/Config.php';
if (!Config::exists()) {
    http_response_code(500);
    echo json_encode(['message' => 'فایل config.php پیدا نشد. از config.sample.php کپی بگیرید.'], JSON_UNESCAPED_UNICODE);
    exit;
}

require $root . '/src/Database.php';
require $root . '/src/Rules.php';
require $root . '/src/Auth.php';
require $root . '/src/Schema.php';
require $root . '/src/Finance.php';
require $root . '/src/Settings.php';
require $root . '/src/Excel.php';
require $root . '/src/Jalali.php';

$cfg = Config::load();
if (!empty($cfg['debug'])) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
}

// مسیر: /api/xxx یا xxx
// اولویت: ?r= / PATH_INFO / URL — برای هاست بدون mod_rewrite
$path = '';
if (!empty($_GET['r'])) {
    $path = '/' . trim((string)$_GET['r'], '/');
} elseif (!empty($_SERVER['PATH_INFO'])) {
    $path = '/' . trim((string)$_SERVER['PATH_INFO'], '/');
} else {
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = parse_url($uri, PHP_URL_PATH) ?: '/';
    $path = preg_replace('#^.*/api(?:/index\.php)?#', '', $path);
    $path = '/' . trim($path, '/');
}
if ($path === '/' || $path === '') {
    $path = '/health';
}
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

$body = [];
$raw = file_get_contents('php://input');
if ($raw) {
    $body = json_decode($raw, true) ?: [];
}
if (!$body && !empty($_POST)) {
    $body = $_POST;
}

function json_out($data, int $code = 200): void
{
    http_response_code($code);
    if ($code >= 400 && is_array($data)) {
        // سازگاری با فرانت: هم message و هم error
        if (isset($data['message']) && !isset($data['error'])) {
            $data['error'] = $data['message'];
        }
        if (isset($data['error']) && !isset($data['message'])) {
            $data['message'] = $data['error'];
        }
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function read_json_body(): array
{
    global $body;
    return is_array($body) ? $body : [];
}

try {
    // مهاجرت فقط وقتی نسخه‌ی اسکیما قدیمی است
    Schema::ensure();

    // مسیرهای عمومی
    $public = ['/health', '/login', '/setup'];
    $isPublic = in_array($path, $public, true);

    if (!$isPublic && $method !== 'GET') {
        $client = $_SERVER['HTTP_X_SONIA_CLIENT'] ?? '';
        Rules::require($client === '1', 'درخواست نامعتبر است', 403);
    }

    $actor = null;
    $tokenHash = null;
    if (!$isPublic) {
        $auth = Auth::requireUser();
        $actor = $auth['user'];
        $tokenHash = $auth['tokenHash'];
    }

    // -------- مسیرها --------
    if ($path === '/health' && $method === 'GET') {
        json_out([
            'application' => 'Sonia',
            'version' => '0.1.0-php',
            'mode' => 'pure-php',
            'setupRequired' => Auth::userCount() === 0,
        ]);
    }

    if ($path === '/setup' && $method === 'POST') {
        json_out(Auth::setup(read_json_body()));
    }

    if ($path === '/login' && $method === 'POST') {
        json_out(Auth::login(read_json_body()));
    }

    if ($path === '/logout' && $method === 'POST') {
        json_out(Auth::logout($tokenHash));
    }

    if ($path === '/me' && $method === 'GET') {
        json_out([
            'id' => $actor['id'],
            'role' => $actor['role'],
            'isAdmin' => $actor['role'] === 'Admin',
            'name' => $actor['name'],
        ]);
    }

    if ($path === '/password' && $method === 'POST') {
        $in = read_json_body();
        Rules::require(password_verify((string) ($in['current'] ?? ''), $actor['password']), 'رمز فعلی اشتباه است');
        $next = (string) ($in['next'] ?? '');
        Rules::require(mb_strlen($next) >= 12 && mb_strlen($next) <= 200, 'رمز باید بین ۱۲ تا ۲۰۰ نویسه باشد');
        Database::pdo()->prepare('UPDATE users SET password=? WHERE id=?')
            ->execute([password_hash($next, PASSWORD_DEFAULT), $actor['id']]);
        Database::pdo()->prepare('DELETE FROM sessions WHERE user_id=? AND hash!=?')->execute([$actor['id'], $tokenHash]);
        json_out(['ok' => true]);
    }

    if ($path === '/catalog' && $method === 'GET') {
        json_out(Finance::catalog($actor));
    }

    if ($path === '/products' && $method === 'POST') {
        json_out(Finance::createProduct($actor, read_json_body()));
    }

    if (preg_match('#^/products/([0-9a-f\-]{36})$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::updateProduct($actor, $m[1], read_json_body()));
    }

    if (preg_match('#^/products/([0-9a-f\-]{36})/batches$#i', $path, $m) && $method === 'GET') {
        Auth::requireAdmin($actor);
        json_out(Finance::productBatches($m[1]));
    }

    if (preg_match('#^/batches/([0-9a-f\-]{36})/writeoff$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::writeOffBatch($actor, $m[1], read_json_body()));
    }

    if ($path === '/prices' && $method === 'POST') {
        json_out(Finance::setPrice($actor, read_json_body()));
    }

    if ($path === '/customers' && $method === 'POST') {
        json_out(Finance::createCustomer($actor, read_json_body()));
    }

    if (preg_match('#^/customers/([0-9a-f\-]{36})$#i', $path, $m) && $method === 'POST') {
        // update customer vs opening-receive — بر اساس body تشخیص
        $in = read_json_body();
        if (isset($in['payment']) || isset($in['method'])) {
            json_out(Finance::receiveOpening($actor, $m[1], $in));
        }
        json_out(Finance::updateCustomer($actor, $m[1], $in));
    }

    if (preg_match('#^/customers/([0-9a-f\-]{36})/opening-receive$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::receiveOpening($actor, $m[1], read_json_body()));
    }

    if (preg_match('#^/customers/([0-9a-f\-]{36})/balance$#i', $path, $m) && $method === 'GET') {
        Finance::assertCustomerAccess($actor, $m[1]);
        json_out(Finance::balance($m[1]));
    }

    if ($path === '/visitors' && $method === 'POST') {
        json_out(Finance::createVisitor($actor, read_json_body()));
    }

    if ($path === '/levels' && $method === 'POST') {
        json_out(Finance::createLevel($actor, read_json_body()));
    }

    if ($path === '/stock' && $method === 'POST') {
        json_out(Finance::adjustStock($actor, read_json_body()));
    }

    if ($path === '/orders' && $method === 'GET') {
        $db = Database::pdo();
        if ($actor['role'] === 'Admin') {
            $orders = $db->query('SELECT * FROM orders ORDER BY at DESC LIMIT 500')->fetchAll();
        } else {
            $st = $db->prepare('SELECT * FROM orders WHERE creator_id=? ORDER BY at DESC LIMIT 500');
            $st->execute([$actor['id']]);
            $orders = $st->fetchAll();
        }
        $out = [];
        $byOrder = [];
        if ($orders) {
            $ids = array_column($orders, 'id');
            $ph = implode(',', array_fill(0, count($ids), '?'));
            $st = $db->prepare("SELECT * FROM order_lines WHERE order_id IN ($ph)");
            $st->execute($ids);
            foreach ($st->fetchAll() as $l) {
                $byOrder[$l['order_id']][] = $l;
            }
        }
        foreach ($orders as $o) {
            $lines = [];
            foreach ($byOrder[$o['id']] ?? [] as $l) {
                $lines[] = [
                    'id' => $l['id'],
                    'productId' => $l['product_id'],
                    'name' => $l['name'],
                    'unit' => $l['unit'],
                    'quantity' => (float) $l['quantity'],
                    'price' => (float) $l['price'],
                    'total' => (float) $l['total'],
                ];
            }
            $out[] = [
                'id' => $o['id'],
                'customerId' => $o['customer_id'],
                'warehouseId' => $o['warehouse_id'],
                'creatorId' => $o['creator_id'],
                'channel' => $o['channel'],
                'status' => $o['status'],
                'discount' => (float) $o['discount'],
                'at' => $o['at'],
                'lines' => $lines,
            ];
        }
        json_out($out);
    }

    if ($path === '/orders' && $method === 'POST') {
        json_out(Finance::submitOrder($actor, read_json_body()));
    }

    if (preg_match('#^/orders/([0-9a-f\-]{36})/approve$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::approveOrder($actor, $m[1], read_json_body()));
    }

    if (preg_match('#^/orders/([0-9a-f\-]{36})/reject$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::rejectOrder($actor, $m[1]));
    }

    if ($path === '/invoices' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query('SELECT i.*, o.customer_id FROM invoices i JOIN orders o ON o.id=i.order_id ORDER BY i.number DESC LIMIT 500')->fetchAll();
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id' => $r['id'],
                'orderId' => $r['order_id'],
                'customerId' => $r['customer_id'],
                'number' => (int) $r['number'],
                'total' => (float) $r['total'],
                'status' => $r['status'],
                'at' => $r['at'],
            ];
        }
        json_out($out);
    }

    if (preg_match('#^/invoices/([0-9a-f\-]{36})$#i', $path, $m) && $method === 'GET') {
        Auth::requireAdmin($actor);
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM invoices WHERE id=?');
        $st->execute([$m[1]]);
        $inv = $st->fetch();
        Rules::require((bool) $inv, 'فاکتور یافت نشد', 404);
        $st = $db->prepare('SELECT * FROM orders WHERE id=?');
        $st->execute([$inv['order_id']]);
        $order = $st->fetch();
        $st = $db->prepare('SELECT * FROM order_lines WHERE order_id=?');
        $st->execute([$order['id']]);
        $order['lines'] = $st->fetchAll();
        $st = $db->prepare('SELECT * FROM customers WHERE id=?');
        $st->execute([$order['customer_id']]);
        $customer = $st->fetch();
        $st = $db->prepare('SELECT * FROM payments WHERE invoice_id=?');
        $st->execute([$inv['id']]);
        $payments = $st->fetchAll();
        $checks = [];
        if ($payments) {
            $ids = array_column($payments, 'id');
            $in = implode(',', array_fill(0, count($ids), '?'));
            $st = $db->prepare("SELECT * FROM checks WHERE payment_id IN ($in)");
            $st->execute($ids);
            $checks = $st->fetchAll();
        }
        json_out(['invoice' => $inv, 'order' => $order, 'customer' => $customer, 'payments' => $payments, 'checks' => $checks]);
    }

    if (preg_match('#^/invoices/([0-9a-f\-]{36})/receive$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::receive($actor, $m[1], read_json_body()));
    }

    if (preg_match('#^/invoices/([0-9a-f\-]{36})/void$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::voidInvoice($actor, $m[1], read_json_body()));
    }

    if ($path === '/checks' && $method === 'GET') {
        Auth::requireAdmin($actor);
        json_out(Database::pdo()->query('SELECT * FROM checks ORDER BY due')->fetchAll());
    }

    if (preg_match('#^/checks/([0-9a-f\-]{36})/status$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::changeCheck($actor, $m[1], read_json_body()));
    }

    if ($path === '/dashboard' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $db = Database::pdo();
        $invoices = $db->query("SELECT * FROM invoices WHERE status='Posted'")->fetchAll();
        $totalSales = 0;
        foreach ($invoices as $i) {
            $totalSales += (float) $i['total'];
        }
        $opening = (float) $db->query('SELECT COALESCE(SUM(opening_debt),0) FROM customers')->fetchColumn();
        $paidCash = (float) $db->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE method!='Check'")->fetchColumn();
        $paidChecks = (float) $db->query("SELECT COALESCE(SUM(amount),0) FROM checks WHERE status='Collected'")->fetchColumn();
        $pending = (int) $db->query("SELECT COUNT(*) FROM checks WHERE status='Pending'")->fetchColumn();
        $isLite = $db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
        $dueSoon = (int) $db->query($isLite
            ? "SELECT COUNT(*) FROM checks WHERE status='Pending' AND due <= date('now','+7 day')"
            : "SELECT COUNT(*) FROM checks WHERE status='Pending' AND due <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)")->fetchColumn();
        $openingPaid = (float) $db->query('SELECT COALESCE(SUM(amount),0) FROM opening_receipts')->fetchColumn();
        json_out([
            'invoiceCount' => count($invoices),
            'totalSales' => $totalSales,
            'receivable' => $opening + $totalSales - $paidCash - $paidChecks - $openingPaid,
            'collected' => $paidCash + $paidChecks + $openingPaid,
            'pendingChecks' => $pending,
            'dueSoon' => $dueSoon,
            'lowStock' => Finance::lowStock(),
            'expiry' => Finance::expirySummary(),
        ]);
    }

    if ($path === '/reports/sales' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $from = $_GET['from'] ?? null;
        $to = $_GET['to'] ?? null;
        $db = Database::pdo();
        $sql = "SELECT i.number, i.at, i.total, o.channel, o.customer_id, c.name AS customer_name
                FROM invoices i
                JOIN orders o ON o.id = i.order_id
                JOIN customers c ON c.id = o.customer_id
                WHERE i.status='Posted'";
        $params = [];
        if ($from) { $sql .= ' AND i.at >= ?'; $params[] = $from . ' 00:00:00'; }
        if ($to) { $sql .= ' AND i.at <= ?'; $params[] = $to . ' 23:59:59'; }
        $sql .= ' ORDER BY i.at DESC';
        $st = $db->prepare($sql);
        $st->execute($params);
        $rows = [];
        $total = 0;
        foreach ($st->fetchAll() as $r) {
            $total += (float) $r['total'];
            $rows[] = [
                'number' => $r['number'],
                'date' => $r['at'],
                'customer' => $r['customer_name'],
                'channel' => $r['channel'],
                'total' => (float) $r['total'],
            ];
        }
        $count = count($rows);
        json_out([
            'rows' => $rows,
            'total' => $total,
            'count' => $count,
            'average' => $count ? round($total / $count) : 0,
        ]);
    }

    if ($path === '/reports/sales.csv' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query("SELECT number, at, total FROM invoices WHERE status='Posted' ORDER BY number")->fetchAll();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="sonia-sales.csv"');
        echo "شماره,تاریخ,مبلغ\n";
        foreach ($rows as $r) {
            echo $r['number'] . ',' . $r['at'] . ',' . $r['total'] . "\n";
        }
        exit;
    }

    if ($path === '/notifications' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $db = Database::pdo();
        $lite = $db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
        $rows = $db->query($lite
            ? "SELECT * FROM checks WHERE status='Pending' AND due <= date('now','+7 day') ORDER BY due"
            : "SELECT * FROM checks WHERE status='Pending' AND due <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) ORDER BY due")->fetchAll();
        $out = [];
        foreach ($rows as $c) {
            $out[] = [
                'checkId' => $c['id'],
                'day' => date('Y-m-d'),
                'message' => "چک {$c['number']} بانک {$c['bank']} | " . number_format((float) $c['amount']) . " تومان | سررسید {$c['due']}",
            ];
        }
        json_out($out);
    }

    if ($path === '/audit' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query('SELECT * FROM audits ORDER BY id DESC LIMIT 1000')->fetchAll();
        foreach ($rows as &$r) { $r['actorId'] = $r['actor_id']; $r['targetId'] = $r['target_id']; }
        json_out($rows);
    }

    if ($path === '/movements' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query('SELECT * FROM movements ORDER BY at DESC LIMIT 500')->fetchAll();
        foreach ($rows as &$r) { $r['productId'] = $r['product_id']; $r['warehouseId'] = $r['warehouse_id']; }
        json_out($rows);
    }

    if (preg_match('#^/customers/([0-9a-f\-]{36})/ledger$#i', $path, $m) && $method === 'GET') {
        Finance::assertCustomerAccess($actor, $m[1]);
        $bal = Finance::balance($m[1]);
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM customers WHERE id=?');
        $st->execute([$m[1]]);
        $customer = $st->fetch();
        Rules::require((bool) $customer, 'مشتری یافت نشد', 404);
        $st = $db->prepare("SELECT i.* FROM invoices i JOIN orders o ON o.id=i.order_id WHERE o.customer_id=? AND i.status='Posted' ORDER BY i.at");
        $st->execute([$m[1]]);
        $invoices = $st->fetchAll();
        $st = $db->prepare('SELECT * FROM payments WHERE customer_id=? ORDER BY at');
        $st->execute([$m[1]]);
        $payments = $st->fetchAll();
        json_out(['customer' => $customer, 'balance' => $bal, 'invoices' => $invoices, 'payments' => $payments]);
    }

    
    // ---- users ----
    if ($path === '/users' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query('SELECT id, username, name, role, active FROM users ORDER BY name')->fetchAll();
        foreach ($rows as &$u) {
            $u['active'] = (bool) (int) $u['active'];
        }
        json_out($rows);
    }

    if ($path === '/users' && $method === 'POST') {
        Auth::requireAdmin($actor);
        $in = read_json_body();
        // ایجاد ویزیتور/کاربر
        json_out(Finance::createVisitor($actor, $in));
    }

    if (preg_match('#^/users/([0-9a-f\-]{36})/disable$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::setUserActive($actor, $m[1], false));
    }
    if (preg_match('#^/users/([0-9a-f\-]{36})/enable$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::setUserActive($actor, $m[1], true));
    }
    if (preg_match('#^/users/([0-9a-f\-]{36})/password$#i', $path, $m) && $method === 'POST') {
        json_out(Finance::resetPassword($actor, $m[1], read_json_body()));
    }

    // ---- visits ----
    if ($path === '/visits' && $method === 'GET') {
        $db = Database::pdo();
        if ($actor['role'] === 'Admin') {
            $rows = $db->query('SELECT * FROM visits ORDER BY day DESC LIMIT 500')->fetchAll();
        } else {
            $st = $db->prepare('SELECT * FROM visits WHERE visitor_id=? ORDER BY day DESC LIMIT 500');
            $st->execute([$actor['id']]);
            $rows = $st->fetchAll();
        }
        foreach ($rows as &$v) {
            $v['customerId'] = $v['customer_id'];
            $v['visitorId'] = $v['visitor_id'];
        }
        json_out($rows);
    }

    if ($path === '/visits' && $method === 'POST') {
        Auth::requireAdmin($actor);
        $in = read_json_body();
        Finance::requireRef('customers', $in['customerId'] ?? '', 'مشتری نامعتبر است');
        Finance::requireRef('users', $in['visitorId'] ?? '', 'ویزیتور نامعتبر است');
        $id = Rules::uuid();
        Database::pdo()->prepare('INSERT INTO visits (id, customer_id, visitor_id, day, status) VALUES (?,?,?,?,?)')
            ->execute([$id, $in['customerId'] ?? '', $in['visitorId'] ?? '', $in['day'] ?? date('Y-m-d'), 'Planned']);
        json_out(['id' => $id]);
    }

    
    
    // ========== تنظیمات شرکت / فاکتور ==========
    if ($path === '/settings' && $method === 'GET') {
        json_out(Settings::all());
    }
    if ($path === '/settings' && $method === 'POST') {
        Auth::requireAdmin($actor);
        $in = read_json_body();
        $allowed = [
            'company_name','office_name','invoice_title','proforma_title',
            'invoice_footer','invoice_prefix','proforma_prefix','show_company_on_print',
            'print_template','print_show_logo_text','print_paper',
        ];
        $pairs = [];
        foreach ($allowed as $k) {
            if (array_key_exists($k, $in)) {
                $pairs[$k] = (string) $in[$k];
            }
        }
        Settings::setMany($pairs);
        Finance::audit($actor, 'SettingsUpdated');
        json_out(['ok' => true, 'settings' => Settings::all()]);
    }

    // ========== حضور ویزیتور ==========
    if ($path === '/presence' && $method === 'POST') {
        // ویزیتور هنگام ورود به پنل موقعیت را ثبت می‌کند
        $in = read_json_body();
        $id = Rules::uuid();
        if (random_int(1, 50) === 1) {
            Database::pdo()->prepare('DELETE FROM visitor_presence WHERE at < ?')->execute([date('Y-m-d H:i:s', time() - 90 * 86400)]);
        }
        Database::pdo()->prepare('INSERT INTO visitor_presence (id, visitor_id, lat, lng, accuracy, note, at) VALUES (?,?,?,?,?,?,?)')
            ->execute([
                $id,
                $actor['id'],
                Rules::coord($in['lat'] ?? null, 90),
                Rules::coord($in['lng'] ?? null, 180),
                isset($in['accuracy']) ? (float) $in['accuracy'] : null,
                isset($in['note']) ? mb_substr((string) $in['note'], 0, 200) : null,
                date('Y-m-d H:i:s'),
            ]);
        json_out(['id' => $id, 'ok' => true]);
    }

    if ($path === '/presence' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $db = Database::pdo();
        // آخرین حضور هر ویزیتور
        $users = $db->query("SELECT id, name, username FROM users WHERE role='Visitor'")->fetchAll();
        $out = [];
        foreach ($users as $u) {
            $st = $db->prepare('SELECT * FROM visitor_presence WHERE visitor_id=? ORDER BY at DESC LIMIT 1');
            $st->execute([$u['id']]);
            $p = $st->fetch() ?: null;
            $out[] = [
                'visitorId' => $u['id'],
                'name' => $u['name'],
                'username' => $u['username'],
                'lat' => $p ? $p['lat'] : null,
                'lng' => $p ? $p['lng'] : null,
                'accuracy' => $p ? $p['accuracy'] : null,
                'at' => $p ? $p['at'] : null,
                'note' => $p ? $p['note'] : null,
            ];
        }
        json_out($out);
    }

    if ($path === '/presence/history' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $vid = $_GET['visitorId'] ?? '';
        $st = Database::pdo()->prepare('SELECT * FROM visitor_presence WHERE visitor_id=? ORDER BY at DESC LIMIT 100');
        $st->execute([$vid]);
        json_out($st->fetchAll());
    }

    // ========== گزارش انبار ==========
    if ($path === '/reports/stock' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $db = Database::pdo();
        $rows = $db->query(
            'SELECT p.sku, p.name, p.unit, p.minimum_stock, COALESCE(s.quantity,0) AS quantity, w.name AS warehouse
             FROM products p
             CROSS JOIN warehouses w
             LEFT JOIN stocks s ON s.product_id=p.id AND s.warehouse_id=w.id
             ORDER BY p.name'
        )->fetchAll();
        $out = [];
        foreach ($rows as $r) {
            $q = (float) $r['quantity'];
            $min = (float) $r['minimum_stock'];
            $out[] = [
                'sku' => $r['sku'],
                'name' => $r['name'],
                'unit' => $r['unit'],
                'warehouse' => $r['warehouse'],
                'quantity' => $q,
                'minimumStock' => $min,
                'status' => $q <= $min ? 'کم‌موجود' : 'عادی',
            ];
        }
        json_out(['rows' => $out]);
    }

    // ========== خروجی اکسل ==========
    if ($path === '/export/sales' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $from = $_GET['from'] ?? null;
        $to = $_GET['to'] ?? null;
        $db = Database::pdo();
        $sql = "SELECT i.number, i.at, c.name AS customer, o.channel, i.total, i.status
                FROM invoices i JOIN orders o ON o.id=i.order_id JOIN customers c ON c.id=o.customer_id WHERE 1=1";
        $params = [];
        if ($from) { $sql .= ' AND i.at>=?'; $params[] = $from.' 00:00:00'; }
        if ($to) { $sql .= ' AND i.at<=?'; $params[] = $to.' 23:59:59'; }
        $sql .= ' ORDER BY i.number';
        $st = $db->prepare($sql);
        $st->execute($params);
        $rows = [];
        foreach ($st->fetchAll() as $r) {
            $rows[] = [$r['number'], $r['at'], $r['customer'], $r['channel'], $r['total'], $r['status']];
        }
        Excel::send('sonia-sales', ['شماره','تاریخ','مشتری','کانال','مبلغ','وضعیت'], $rows);
    }

    if ($path === '/export/stock' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $db = Database::pdo();
        $rows = $db->query(
            'SELECT p.sku, p.name, p.unit, w.name AS warehouse, COALESCE(s.quantity,0), p.minimum_stock
             FROM products p CROSS JOIN warehouses w
             LEFT JOIN stocks s ON s.product_id=p.id AND s.warehouse_id=w.id ORDER BY p.name'
        )->fetchAll(PDO::FETCH_NUM);
        Excel::send('sonia-stock', ['کد','کالا','واحد','انبار','موجودی','حداقل'], $rows);
    }

    if ($path === '/export/customers' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query(
            'SELECT c.name, c.phone, c.address, pl.name, u.name, c.opening_debt
             FROM customers c
             LEFT JOIN price_levels pl ON pl.id=c.price_level_id
             LEFT JOIN users u ON u.id=c.visitor_id
             ORDER BY c.name'
        )->fetchAll(PDO::FETCH_NUM);
        Excel::send('sonia-customers', ['مشتری','تلفن','آدرس','سطح قیمت','ویزیتور','بدهی اول دوره'], $rows);
    }

    if ($path === '/export/expiring' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $days = (int) ($_GET['days'] ?? 30);
        $days = max(1, min(365, $days));
        $until = date('Y-m-d', time() + $days * 86400);
        $st = Database::pdo()->prepare(
            'SELECT p.sku, p.name AS product_name, w.name AS warehouse_name, b.quantity, b.expires_on, b.at, b.lot_no
             FROM stock_batches b
             JOIN products p ON p.id=b.product_id
             JOIN warehouses w ON w.id=b.warehouse_id
             WHERE b.quantity>0 AND b.depleted_at IS NULL AND b.expires_on IS NOT NULL AND b.expires_on<=?
             ORDER BY b.expires_on'
        );
        $st->execute([$until]);
        $rows = [];
        foreach ($st->fetchAll() as $r) {
            $rows[] = [
                $r['sku'],
                $r['product_name'],
                $r['warehouse_name'],
                $r['quantity'],
                Jalali::formatShamsi($r['expires_on']),
                Jalali::formatShamsi(substr($r['at'], 0, 10)),
                $r['lot_no'] ?? '',
            ];
        }
        Excel::send('sonia-expiring', ['کد','کالا','انبار','موجودی','انقضا شمسی','ورود شمسی','لات'], $rows);
    }

    if ($path === '/export/movements' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query(
            'SELECT m.at, p.name, m.delta, m.reason FROM movements m
             JOIN products p ON p.id=m.product_id ORDER BY m.at DESC LIMIT 5000'
        )->fetchAll(PDO::FETCH_NUM);
        Excel::send('sonia-movements', ['تاریخ','کالا','تغییر','شرح'], $rows);
    }

    // ========== پیش‌فاکتور ==========
    if ($path === '/proformas' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query('SELECT * FROM proformas ORDER BY number DESC LIMIT 300')->fetchAll();
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id' => $r['id'],
                'number' => (int) $r['number'],
                'customerId' => $r['customer_id'],
                'total' => (float) $r['total'],
                'discount' => (float) $r['discount'],
                'status' => $r['status'],
                'note' => $r['note'],
                'at' => $r['at'],
            ];
        }
        json_out($out);
    }

    if ($path === '/proformas' && $method === 'POST') {
        Auth::requireAdmin($actor);
        $in = read_json_body();
        $db = Database::pdo();
        $customerId = $in['customerId'] ?? '';
        $linesIn = $in['lines'] ?? [];
        Rules::require($customerId && is_array($linesIn) && count($linesIn) > 0 && count($linesIn) <= 200, 'مشتری و اقلام لازم است');
        $cst = $db->prepare('SELECT * FROM customers WHERE id=?');
        $cst->execute([$customerId]);
        $customer = $cst->fetch();
        Rules::require((bool) $customer, 'مشتری یافت نشد');
        $sum = 0;
        $prepared = [];
        foreach ($linesIn as $line) {
            $st = $db->prepare('SELECT * FROM products WHERE id=?');
            $st->execute([$line['productId'] ?? '']);
            $p = $st->fetch();
            Rules::require((bool) $p, 'کالا یافت نشد');
            $price = Finance::resolvePrice($actor, $customer, $p, (array) $line);
            $total = (float) Rules::lineTotal($p['unit'], $line['quantity'] ?? 0, $price);
            $sum += $total;
            $prepared[] = [$p, (float) $line['quantity'], Rules::money($price), Rules::money($total)];
        }
        $discount = (float) Rules::money($in['discount'] ?? 0);
        Rules::require($discount >= 0 && $discount <= $sum, 'تخفیف نامعتبر');
        $number = Finance::nextNumber('proformas');
        $id = Rules::uuid();
        $wh = $in['warehouseId'] ?? $db->query('SELECT id FROM warehouses LIMIT 1')->fetchColumn();
        Finance::requireRef('warehouses', (string) $wh, 'انبار نامعتبر است');
        $db->prepare('INSERT INTO proformas (id, number, customer_id, warehouse_id, creator_id, discount, total, status, note, at) VALUES (?,?,?,?,?,?,?,?,?,?)')
            ->execute([$id, $number, $customerId, $wh, $actor['id'], $discount, Rules::money($sum - $discount), 'Draft', $in['note'] ?? null, date('Y-m-d H:i:s')]);
        foreach ($prepared as [$p, $qty, $price, $total]) {
            $db->prepare('INSERT INTO proforma_lines (id, proforma_id, product_id, name, unit, quantity, price, total) VALUES (?,?,?,?,?,?,?,?)')
                ->execute([Rules::uuid(), $id, $p['id'], $p['name'], $p['unit'], $qty, $price, $total]);
        }
        Finance::audit($actor, 'ProformaCreated', $id, (string) $number);
        json_out(['id' => $id, 'number' => $number]);
    }


    
    // ---- قیمت اختصاصی مشتری ----
    if ($path === '/customer-prices' && $method === 'GET') {
        $cid = $_GET['customerId'] ?? '';
        Rules::require($cid !== '', 'مشتری لازم است');
        Finance::assertCustomerAccess($actor, (string) $cid);
        $st = Database::pdo()->prepare('SELECT product_id AS productId, amount FROM customer_prices WHERE customer_id=?');
        $st->execute([$cid]);
        json_out($st->fetchAll());
    }
    if ($path === '/customer-prices' && $method === 'POST') {
        Auth::requireAdmin($actor);
        $in = read_json_body();
        $cid = $in['customerId'] ?? '';
        $pid = $in['productId'] ?? '';
        $amount = Rules::money($in['amount'] ?? 0);
        Rules::require($cid && $pid, 'مشتری و کالا لازم است');
        $db = Database::pdo();
        if ($db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
            $db->prepare('INSERT OR REPLACE INTO customer_prices (customer_id, product_id, amount) VALUES (?,?,?)')->execute([$cid, $pid, $amount]);
        } else {
            $db->prepare('INSERT INTO customer_prices (customer_id, product_id, amount) VALUES (?,?,?) ON DUPLICATE KEY UPDATE amount=VALUES(amount)')->execute([$cid, $pid, $amount]);
        }
        json_out(['ok' => true]);
    }

    // ---- جزئیات کامل مشتری ----
    if (preg_match('#^/customers/([0-9a-f\-]{36})/detail$#i', $path, $m) && $method === 'GET') {
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM customers WHERE id=?');
        $st->execute([$m[1]]);
        $c = $st->fetch();
        Rules::require((bool) $c, 'مشتری یافت نشد', 404);
        if ($actor['role'] !== 'Admin') {
            Rules::require($c['visitor_id'] === $actor['id'], 'دسترسی ندارید', 403);
        }
        $bal = Finance::balance($m[1]);
        $st = $db->prepare("SELECT i.*, o.channel FROM invoices i JOIN orders o ON o.id=i.order_id WHERE o.customer_id=? ORDER BY i.at DESC LIMIT 100");
        $st->execute([$m[1]]);
        $invoices = $st->fetchAll();
        $st = $db->prepare('SELECT * FROM orders WHERE customer_id=? ORDER BY at DESC LIMIT 100');
        $st->execute([$m[1]]);
        $orders = $st->fetchAll();
        $st = $db->prepare('SELECT * FROM payments WHERE customer_id=? ORDER BY at DESC LIMIT 100');
        $st->execute([$m[1]]);
        $payments = $st->fetchAll();
        $st = $db->prepare('SELECT * FROM visits WHERE customer_id=? ORDER BY day DESC LIMIT 50');
        $st->execute([$m[1]]);
        $visits = $st->fetchAll();
        $st = $db->prepare('SELECT product_id AS productId, amount FROM customer_prices WHERE customer_id=?');
        $st->execute([$m[1]]);
        $customPrices = $st->fetchAll();
        $level = $db->prepare('SELECT name FROM price_levels WHERE id=?');
        $level->execute([$c['price_level_id']]);
        json_out([
            'customer' => [
                'id' => $c['id'], 'name' => $c['name'], 'phone' => $c['phone'], 'address' => $c['address'],
                'priceLevelId' => $c['price_level_id'], 'priceLevelName' => $level->fetchColumn(),
                'visitorId' => $c['visitor_id'], 'openingDebt' => (float) $c['opening_debt'],
            ],
            'balance' => $bal,
            'invoices' => $invoices,
            'orders' => $orders,
            'payments' => $payments,
            'visits' => $visits,
            'customPrices' => $customPrices,
        ]);
    }

    // ---- گردش انبار با فیلتر ----
    if ($path === '/reports/movements' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $from = $_GET['from'] ?? null;
        $to = $_GET['to'] ?? null;
        $productId = $_GET['productId'] ?? null;
        $sql = 'SELECT m.*, p.name AS product_name, p.sku FROM movements m JOIN products p ON p.id=m.product_id WHERE 1=1';
        $params = [];
        if ($from) { $sql .= ' AND m.at>=?'; $params[] = $from.' 00:00:00'; }
        if ($to) { $sql .= ' AND m.at<=?'; $params[] = $to.' 23:59:59'; }
        if ($productId) { $sql .= ' AND m.product_id=?'; $params[] = $productId; }
        $sql .= ' ORDER BY m.at DESC LIMIT 2000';
        $st = Database::pdo()->prepare($sql);
        $st->execute($params);
        $rows = [];
        foreach ($st->fetchAll() as $r) {
            $rows[] = [
                'id' => $r['id'], 'at' => $r['at'], 'productId' => $r['product_id'],
                'productName' => $r['product_name'], 'sku' => $r['sku'],
                'delta' => (float) $r['delta'], 'reason' => $r['reason'], 'sourceId' => $r['source_id'],
            ];
        }
        json_out(['rows' => $rows, 'count' => count($rows)]);
    }

    // ---- یادداشت گزارش ----
    if ($path === '/report-notes' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $rows = Database::pdo()->query('SELECT * FROM report_notes ORDER BY at DESC LIMIT 200')->fetchAll();
        json_out($rows);
    }
    if ($path === '/report-notes' && $method === 'POST') {
        Auth::requireAdmin($actor);
        $in = read_json_body();
        $title = Rules::text($in['title'] ?? null, 200);
        $body = Rules::text($in['body'] ?? null, 5000);
        $id = Rules::uuid();
        Database::pdo()->prepare('INSERT INTO report_notes (id, author_id, title, body, related_type, related_id, at) VALUES (?,?,?,?,?,?,?)')
            ->execute([$id, $actor['id'], $title, $body, $in['relatedType'] ?? null, $in['relatedId'] ?? null, date('Y-m-d H:i:s')]);
        json_out(['id' => $id]);
    }

    // ---- جزئیات سفارش ----
    if (preg_match('#^/orders/([0-9a-f\-]{36})$#i', $path, $m) && $method === 'GET') {
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM orders WHERE id=?');
        $st->execute([$m[1]]);
        $o = $st->fetch();
        Rules::require((bool) $o, 'سفارش یافت نشد', 404);
        Finance::assertOrderAccess($actor, $o);
        $st = $db->prepare('SELECT * FROM order_lines WHERE order_id=?');
        $st->execute([$m[1]]);
        $lines = $st->fetchAll();
        $st = $db->prepare('SELECT * FROM customers WHERE id=?');
        $st->execute([$o['customer_id']]);
        $customer = $st->fetch();
        $st = $db->prepare('SELECT * FROM invoices WHERE order_id=?');
        $st->execute([$m[1]]);
        $invoice = $st->fetch() ?: null;
        json_out([
            'order' => [
                'id' => $o['id'], 'customerId' => $o['customer_id'], 'warehouseId' => $o['warehouse_id'],
                'creatorId' => $o['creator_id'], 'channel' => $o['channel'], 'status' => $o['status'],
                'discount' => (float) $o['discount'], 'at' => $o['at'],
            ],
            'lines' => array_map(fn($l) => [
                'id' => $l['id'], 'productId' => $l['product_id'], 'name' => $l['name'], 'unit' => $l['unit'],
                'quantity' => (float) $l['quantity'], 'price' => (float) $l['price'], 'total' => (float) $l['total'],
            ], $lines),
            'customer' => $customer,
            'invoice' => $invoice,
            'settings' => Settings::all(),
        ]);
    }

    // ---- ویزیت: انجام / عدم انجام ----
    if (preg_match('#^/visits/([0-9a-f\-]{36})/complete$#i', $path, $m) && $method === 'POST') {
        $in = read_json_body();
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM visits WHERE id=?');
        $st->execute([$m[1]]);
        $v = $st->fetch();
        Rules::require((bool) $v, 'بازدید یافت نشد', 404);
        if ($actor['role'] !== 'Admin') {
            Rules::require($v['visitor_id'] === $actor['id'], 'دسترسی ندارید', 403);
        }
        $db->prepare("UPDATE visits SET status='Completed', checkin_lat=?, checkin_lng=?, completed_at=?, skip_reason=NULL WHERE id=?")
            ->execute([
                Rules::coord($in['lat'] ?? null, 90),
                Rules::coord($in['lng'] ?? null, 180),
                date('Y-m-d H:i:s'),
                $m[1],
            ]);
        // همچنین در presence ثبت شود
        $db->prepare('INSERT INTO visitor_presence (id, visitor_id, lat, lng, accuracy, note, at) VALUES (?,?,?,?,?,?,?)')
            ->execute([Rules::uuid(), $v['visitor_id'], Rules::coord($in['lat'] ?? null, 90), Rules::coord($in['lng'] ?? null, 180), Rules::coord($in['accuracy'] ?? null, 100000), 'بازدید مشتری', date('Y-m-d H:i:s')]);
        json_out(['ok' => true]);
    }

    if (preg_match('#^/visits/([0-9a-f\-]{36})/skip$#i', $path, $m) && $method === 'POST') {
        $in = read_json_body();
        $reason = Rules::text($in['reason'] ?? null, 300);
        $db = Database::pdo();
        $st = $db->prepare('SELECT * FROM visits WHERE id=?');
        $st->execute([$m[1]]);
        $v = $st->fetch();
        Rules::require((bool) $v, 'بازدید یافت نشد', 404);
        if ($actor['role'] !== 'Admin') {
            Rules::require($v['visitor_id'] === $actor['id'], 'دسترسی ندارید', 403);
        }
        $db->prepare("UPDATE visits SET status='Skipped', skip_reason=?, completed_at=? WHERE id=?")
            ->execute([$reason, date('Y-m-d H:i:s'), $m[1]]);
        json_out(['ok' => true]);
    }

    // برنامه کاری ویزیتورها (برای پنل مدیر)
    if ($path === '/visits/board' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $day = $_GET['day'] ?? date('Y-m-d');
        $db = Database::pdo();
        $st = $db->prepare('SELECT v.*, c.name AS customer_name, c.address AS customer_address, u.name AS visitor_name
            FROM visits v
            JOIN customers c ON c.id=v.customer_id
            JOIN users u ON u.id=v.visitor_id
            WHERE v.day=? ORDER BY u.name, c.name');
        $st->execute([$day]);
        $rows = $st->fetchAll();
        $summary = ['Planned' => 0, 'InProgress' => 0, 'Completed' => 0, 'Skipped' => 0];
        foreach ($rows as $r) {
            $summary[$r['status']] = ($summary[$r['status']] ?? 0) + 1;
        }
        json_out(['day' => $day, 'rows' => $rows, 'summary' => $summary]);
    }


    
    // ---- کالاهای در حال انقضا / دسته‌ها ----
    if ($path === '/reports/expiring' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $days = (int) ($_GET['days'] ?? 30);
        if ($days < 1) $days = 30;
        if ($days > 365) $days = 365;
        $db = Database::pdo();
        $until = date('Y-m-d', time() + $days * 86400);
        $today = date('Y-m-d');
        // منقضی‌شده + در بازه
        $st = $db->prepare(
            'SELECT b.id, b.product_id, b.warehouse_id, b.quantity, b.expires_on, b.at, b.lot_no, b.diff_days,
                    p.name AS product_name, p.sku, p.unit, w.name AS warehouse_name
             FROM stock_batches b
             JOIN products p ON p.id = b.product_id
             JOIN warehouses w ON w.id = b.warehouse_id
             WHERE b.quantity > 0 AND b.depleted_at IS NULL AND b.expires_on IS NOT NULL AND b.expires_on <= ?
             ORDER BY b.expires_on ASC'
        );
        $st->execute([$until]);
        $rows = [];
        foreach ($st->fetchAll() as $r) {
            $exp = $r['expires_on'];
            $daysLeft = (int) round((strtotime($exp) - strtotime($today)) / 86400);
            $rows[] = [
                'batchId' => $r['id'],
                'lotNo' => $r['lot_no'],
                'diffDays' => isset($r['diff_days']) ? (int) $r['diff_days'] : null,
                'productId' => $r['product_id'],
                'sku' => $r['sku'],
                'name' => $r['product_name'],
                'unit' => $r['unit'],
                'warehouse' => $r['warehouse_name'],
                'quantity' => (float) $r['quantity'],
                'expiresOn' => $exp,
                'expiresOnShamsi' => Jalali::formatShamsi($exp),
                'daysLeft' => $daysLeft,
                'status' => $daysLeft < 0 ? 'منقضی' : ($daysLeft <= 7 ? 'فوری' : 'نزدیک'),
                'receivedAt' => $r['at'],
                'receivedAtShamsi' => Jalali::formatShamsi(substr($r['at'], 0, 10)),
            ];
        }
        json_out(['days' => $days, 'until' => $until, 'untilShamsi' => Jalali::formatShamsi($until), 'rows' => $rows]);
    }

    if ($path === '/batches' && $method === 'GET') {
        Auth::requireAdmin($actor);
        $productId = $_GET['productId'] ?? '';
        $db = Database::pdo();
        if ($productId) {
            $st = $db->prepare(
                'SELECT b.*, p.name AS product_name, p.sku, w.name AS warehouse_name
                 FROM stock_batches b
                 JOIN products p ON p.id=b.product_id
                 JOIN warehouses w ON w.id=b.warehouse_id
                 WHERE b.product_id=? AND b.quantity>0 AND b.depleted_at IS NULL
                 ORDER BY CASE WHEN b.expires_on IS NULL THEN 1 ELSE 0 END, b.expires_on ASC'
            );
            $st->execute([$productId]);
        } else {
            $st = $db->query(
                'SELECT b.*, p.name AS product_name, p.sku, w.name AS warehouse_name
                 FROM stock_batches b
                 JOIN products p ON p.id=b.product_id
                 JOIN warehouses w ON w.id=b.warehouse_id
                 WHERE b.quantity>0 AND b.depleted_at IS NULL
                 ORDER BY b.expires_on IS NULL, b.expires_on ASC LIMIT 500'
            );
        }
        $rows = [];
        foreach ($st->fetchAll() as $r) {
            $rows[] = [
                'id' => $r['id'],
                'productId' => $r['product_id'],
                'sku' => $r['sku'],
                'name' => $r['product_name'],
                'warehouse' => $r['warehouse_name'],
                'quantity' => (float) $r['quantity'],
                'lotNo' => $r['lot_no'],
                'diffDays' => isset($r['diff_days']) ? (int) $r['diff_days'] : null,
                'expiresOnShamsi' => $r['expires_on'] ? Jalali::formatShamsi($r['expires_on']) : '—',
                'expiresOn' => $r['expires_on'],
                'atShamsi' => Jalali::formatShamsi(substr($r['at'], 0, 10)),
            ];
        }
        json_out(['rows' => $rows]);
    }


    json_out(['message' => 'مسیر یافت نشد: ' . $path], 404);

} catch (RuleException $e) {
    json_out(['message' => $e->getMessage()], $e->status);
} catch (Throwable $e) {
    $msg = !empty($cfg['debug']) ? $e->getMessage() : 'خطای داخلی سرور';
    json_out(['message' => $msg], 500);
}
