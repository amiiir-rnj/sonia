<?php
/**
 * نصب یک‌بارمصرف جداول — فقط با کلید راه‌اندازی:
 *   https://your-domain.com/install.php?key=SETUP_KEY   (مقدار setup_key در config.php)
 * بعد از موفقیت، فایل خودش را حذف می‌کند؛ اگر نشد دستی حذفش کنید.
 */
header('Content-Type: text/html; charset=utf-8');
header('X-Robots-Tag: noindex');
$root = __DIR__;
require $root . '/src/Config.php';
if (!Config::exists()) { http_response_code(500); exit('config.php وجود ندارد.'); }
$cfg = Config::load();
$k = (string) ($cfg['setup_key'] ?? '');
if ($k === '' || !hash_equals($k, (string) ($_GET['key'] ?? ''))) {
    http_response_code(403);
    exit('دسترسی ندارید.');
}
require $root . '/src/Database.php';
require $root . '/src/Schema.php';
require $root . '/src/Rules.php';
try {
    Schema::install();
    Schema::upgrade();
    $gone = @unlink(__FILE__);
    echo '<h2 style="color:green">جداول ساخته شدند.</h2><p>به <a href="/">صفحه اصلی</a> بروید و مدیر را بسازید (کلید راه‌اندازی لازم است).</p>';
    echo $gone ? '<p>install.php حذف شد.</p>' : '<p style="color:#b00"><strong>install.php را دستی حذف کنید.</strong></p>';
} catch (Throwable $e) {
    error_log('sonia install: ' . $e->getMessage());
    http_response_code(500);
    echo '<p style="color:red">نصب انجام نشد. اطلاعات اتصال در config.php و لاگ خطای PHP را بررسی کنید.</p>';
}
